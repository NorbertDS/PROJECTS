from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from datetime import datetime

class AnalyticsInsightBase(BaseModel):
    insight_type: str
    title: str
    description: Optional[str] = None
    data: Dict[str, Any]
    confidence_score: Optional[float] = None

class AnalyticsInsightCreate(AnalyticsInsightBase):
    pass

class AnalyticsInsightInDB(AnalyticsInsightBase):
    id: int
    created_at: datetime
    expires_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class AnalyticsInsight(AnalyticsInsightInDB):
    pass

class NaturalLanguageQueryBase(BaseModel):
    query_text: str

class NaturalLanguageQueryCreate(NaturalLanguageQueryBase):
    pass

class NaturalLanguageQueryResponse(BaseModel):
    query_text: str
    response_data: Dict[str, Any]
    created_at: datetime

class SalesForecastRequest(BaseModel):
    product_id: Optional[int] = None
    region: Optional[str] = None
    forecast_periods: int = 12  # months
    confidence_level: float = 0.95

class SalesForecastResponse(BaseModel):
    forecast_data: List[Dict[str, Any]]
    confidence_intervals: List[Dict[str, Any]]
    model_accuracy: float
    insights: List[str]

class AnomalyDetectionResponse(BaseModel):
    anomalies: List[Dict[str, Any]]
    total_anomalies: int
    anomaly_rate: float
    insights: List[str]

class KPIMetrics(BaseModel):
    total_sales: float
    total_profit: float
    profit_margin: float
    sales_growth: float
    top_product: str
    top_region: str
    period: str
