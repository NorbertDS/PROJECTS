from pydantic import BaseModel
from typing import Optional
from datetime import datetime, date
from app.schemas.product import Product

class SaleBase(BaseModel):
    product_id: int
    quantity: int
    unit_price: float
    total_amount: float
    sale_date: date
    region: str
    customer_name: Optional[str] = None
    sales_rep: Optional[str] = None

class SaleCreate(SaleBase):
    pass

class SaleUpdate(BaseModel):
    product_id: Optional[int] = None
    quantity: Optional[int] = None
    unit_price: Optional[float] = None
    total_amount: Optional[float] = None
    sale_date: Optional[date] = None
    region: Optional[str] = None
    customer_name: Optional[str] = None
    sales_rep: Optional[str] = None

class SaleInDB(SaleBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class Sale(SaleInDB):
    product: Optional[Product] = None

class SalesUploadResponse(BaseModel):
    message: str
    records_processed: int
    records_successful: int
    records_failed: int
    errors: Optional[list] = None
