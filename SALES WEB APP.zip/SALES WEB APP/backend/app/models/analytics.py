from sqlalchemy import Column, Integer, String, Float, DateTime, Text, JSON
from sqlalchemy.sql import func
from app.core.database import Base

class AnalyticsInsight(Base):
    __tablename__ = "analytics_insights"

    id = Column(Integer, primary_key=True, index=True)
    insight_type = Column(String, nullable=False, index=True)  # forecast, anomaly, trend, etc.
    title = Column(String, nullable=False)
    description = Column(Text)
    data = Column(JSON)  # Store the actual insight data
    confidence_score = Column(Float)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    expires_at = Column(DateTime(timezone=True))

class NaturalLanguageQuery(Base):
    __tablename__ = "natural_language_queries"

    id = Column(Integer, primary_key=True, index=True)
    query_text = Column(Text, nullable=False)
    response_data = Column(JSON)
    user_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
