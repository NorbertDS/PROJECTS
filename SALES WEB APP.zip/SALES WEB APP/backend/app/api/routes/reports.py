from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session
from typing import Optional
from datetime import date
import io

from app.core.database import get_db
from app.core.security import get_current_active_user
from app.services.report_service import ReportService
from app.models.user import User

router = APIRouter()

@router.get("/profit-loss")
async def get_profit_loss_report(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    product_id: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    report_service = ReportService(db)
    report = report_service.generate_profit_loss_report(
        start_date=start_date,
        end_date=end_date,
        region=region,
        product_id=product_id
    )
    return report

@router.get("/sales-summary")
async def get_sales_summary_report(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    product_id: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    report_service = ReportService(db)
    report = report_service.generate_sales_summary_report(
        start_date=start_date,
        end_date=end_date,
        region=region,
        product_id=product_id
    )
    return report

@router.get("/download/pdf")
async def download_pdf_report(
    report_type: str = "profit-loss",  # profit-loss, sales-summary
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    product_id: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    report_service = ReportService(db)
    
    if report_type == "profit-loss":
        pdf_buffer = report_service.generate_pdf_profit_loss_report(
            start_date=start_date,
            end_date=end_date,
            region=region,
            product_id=product_id
        )
        filename = "profit_loss_report.pdf"
    elif report_type == "sales-summary":
        pdf_buffer = report_service.generate_pdf_sales_summary_report(
            start_date=start_date,
            end_date=end_date,
            region=region,
            product_id=product_id
        )
        filename = "sales_summary_report.pdf"
    else:
        raise HTTPException(status_code=400, detail="Invalid report type")
    
    return StreamingResponse(
        io.BytesIO(pdf_buffer),
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )

@router.get("/download/excel")
async def download_excel_report(
    report_type: str = "profit-loss",  # profit-loss, sales-summary
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    product_id: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    report_service = ReportService(db)
    
    if report_type == "profit-loss":
        excel_buffer = report_service.generate_excel_profit_loss_report(
            start_date=start_date,
            end_date=end_date,
            region=region,
            product_id=product_id
        )
        filename = "profit_loss_report.xlsx"
    elif report_type == "sales-summary":
        excel_buffer = report_service.generate_excel_sales_summary_report(
            start_date=start_date,
            end_date=end_date,
            region=region,
            product_id=product_id
        )
        filename = "sales_summary_report.xlsx"
    else:
        raise HTTPException(status_code=400, detail="Invalid report type")
    
    return StreamingResponse(
        io.BytesIO(excel_buffer),
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )
