from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date, datetime

from app.core.database import get_db
from app.core.security import get_current_active_user
from app.schemas.sale import Sale, SaleCreate, SaleUpdate, SalesUploadResponse
from app.services.sale_service import SaleService
from app.models.user import User

router = APIRouter()

@router.get("/", response_model=List[Sale])
async def get_sales(
    skip: int = 0,
    limit: int = 100,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    product_id: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    sale_service = SaleService(db)
    sales = sale_service.get_sales(
        skip=skip,
        limit=limit,
        start_date=start_date,
        end_date=end_date,
        region=region,
        product_id=product_id
    )
    return sales

@router.get("/{sale_id}", response_model=Sale)
async def get_sale(
    sale_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    sale_service = SaleService(db)
    sale = sale_service.get_sale(sale_id)
    if not sale:
        raise HTTPException(status_code=404, detail="Sale not found")
    return sale

@router.post("/", response_model=Sale)
async def create_sale(
    sale: SaleCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    sale_service = SaleService(db)
    return sale_service.create_sale(sale)

@router.put("/{sale_id}", response_model=Sale)
async def update_sale(
    sale_id: int,
    sale_update: SaleUpdate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    sale_service = SaleService(db)
    sale = sale_service.update_sale(sale_id, sale_update)
    if not sale:
        raise HTTPException(status_code=404, detail="Sale not found")
    return sale

@router.delete("/{sale_id}")
async def delete_sale(
    sale_id: int,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    sale_service = SaleService(db)
    success = sale_service.delete_sale(sale_id)
    if not success:
        raise HTTPException(status_code=404, detail="Sale not found")
    return {"message": "Sale deleted successfully"}

@router.post("/upload", response_model=SalesUploadResponse)
async def upload_sales_data(
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    if not file.filename.endswith(('.csv', '.xlsx', '.xls')):
        raise HTTPException(
            status_code=400,
            detail="File must be CSV or Excel format"
        )
    
    sale_service = SaleService(db)
    result = await sale_service.upload_sales_data(file)
    return result

@router.get("/analytics/summary")
async def get_sales_summary(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    product_id: Optional[int] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    sale_service = SaleService(db)
    summary = sale_service.get_sales_summary(
        start_date=start_date,
        end_date=end_date,
        region=region,
        product_id=product_id
    )
    return summary
