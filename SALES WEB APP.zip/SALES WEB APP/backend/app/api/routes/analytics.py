from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import date

from app.core.database import get_db
from app.core.security import get_current_active_user
from app.schemas.analytics import (
    SalesForecastRequest, 
    SalesForecastResponse,
    AnomalyDetectionResponse,
    KPIMetrics,
    NaturalLanguageQueryCreate,
    NaturalLanguageQueryResponse
)
from app.services.analytics_service import AnalyticsService
from app.models.user import User

router = APIRouter()

@router.get("/kpi", response_model=KPIMetrics)
async def get_kpi_metrics(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    analytics_service = AnalyticsService(db)
    kpi = analytics_service.get_kpi_metrics(
        start_date=start_date,
        end_date=end_date,
        region=region
    )
    return kpi

@router.post("/forecast", response_model=SalesForecastResponse)
async def get_sales_forecast(
    forecast_request: SalesForecastRequest,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    analytics_service = AnalyticsService(db)
    forecast = analytics_service.generate_sales_forecast(forecast_request)
    return forecast

@router.get("/anomalies", response_model=AnomalyDetectionResponse)
async def detect_anomalies(
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    analytics_service = AnalyticsService(db)
    anomalies = analytics_service.detect_anomalies(
        start_date=start_date,
        end_date=end_date,
        region=region
    )
    return anomalies

@router.post("/nl-query", response_model=NaturalLanguageQueryResponse)
async def process_natural_language_query(
    query: NaturalLanguageQueryCreate,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    analytics_service = AnalyticsService(db)
    response = analytics_service.process_natural_language_query(
        query.query_text, current_user.id
    )
    return response

@router.get("/insights/recent")
async def get_recent_insights(
    limit: int = 10,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    analytics_service = AnalyticsService(db)
    insights = analytics_service.get_recent_insights(limit=limit)
    return insights

@router.get("/trends/sales")
async def get_sales_trends(
    period: str = "month",  # day, week, month, year
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    analytics_service = AnalyticsService(db)
    trends = analytics_service.get_sales_trends(
        period=period,
        start_date=start_date,
        end_date=end_date,
        region=region
    )
    return trends

@router.get("/top-products")
async def get_top_products(
    limit: int = 10,
    start_date: Optional[date] = None,
    end_date: Optional[date] = None,
    region: Optional[str] = None,
    current_user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db)
):
    analytics_service = AnalyticsService(db)
    top_products = analytics_service.get_top_products(
        limit=limit,
        start_date=start_date,
        end_date=end_date,
        region=region
    )
    return top_products
