from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_
from typing import List, Optional, Dict, Any
from datetime import date, datetime, timedelta
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
import openai
from app.core.config import settings

from app.models.sale import Sale
from app.models.product import Product
from app.models.analytics import AnalyticsInsight, NaturalLanguageQuery
from app.schemas.analytics import (
    SalesForecastRequest, 
    SalesForecastResponse,
    AnomalyDetectionResponse,
    KPIMetrics,
    NaturalLanguageQueryResponse
)

class AnalyticsService:
    def __init__(self, db: Session):
        self.db = db
        if settings.OPENAI_API_KEY:
            openai.api_key = settings.OPENAI_API_KEY

    def get_kpi_metrics(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None
    ) -> KPIMetrics:
        query = self.db.query(Sale)
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            query = query.filter(Sale.sale_date <= end_date)
        if region:
            query = query.filter(Sale.region == region)
        
        # Calculate KPIs
        total_sales = query.with_entities(func.sum(Sale.total_amount)).scalar() or 0
        
        # Calculate profit (assuming we have cost data)
        sales_with_profit = query.join(Product).with_entities(
            Sale.total_amount,
            Product.cost_price,
            Sale.quantity
        ).all()
        
        total_profit = sum(
            sale.total_amount - (product.cost_price * sale.quantity)
            for sale, product, quantity in sales_with_profit
        )
        
        profit_margin = (total_profit / total_sales * 100) if total_sales > 0 else 0
        
        # Calculate growth (compare with previous period)
        if start_date and end_date:
            period_length = (end_date - start_date).days
            prev_start = start_date - timedelta(days=period_length)
            prev_end = start_date - timedelta(days=1)
            
            prev_sales = self.db.query(Sale).filter(
                and_(Sale.sale_date >= prev_start, Sale.sale_date <= prev_end)
            ).with_entities(func.sum(Sale.total_amount)).scalar() or 0
            
            sales_growth = ((total_sales - prev_sales) / prev_sales * 100) if prev_sales > 0 else 0
        else:
            sales_growth = 0
        
        # Top product and region
        top_product = query.join(Product).with_entities(
            Product.name,
            func.sum(Sale.total_amount).label('total')
        ).group_by(Product.name).order_by(func.sum(Sale.total_amount).desc()).first()
        
        top_region = query.with_entities(
            Sale.region,
            func.sum(Sale.total_amount).label('total')
        ).group_by(Sale.region).order_by(func.sum(Sale.total_amount).desc()).first()
        
        return KPIMetrics(
            total_sales=float(total_sales),
            total_profit=float(total_profit),
            profit_margin=float(profit_margin),
            sales_growth=float(sales_growth),
            top_product=top_product[0] if top_product else "N/A",
            top_region=top_region[0] if top_region else "N/A",
            period=f"{start_date} to {end_date}" if start_date and end_date else "All time"
        )

    def generate_sales_forecast(self, request: SalesForecastRequest) -> SalesForecastResponse:
        # Get historical data
        query = self.db.query(Sale).join(Product)
        
        if request.product_id:
            query = query.filter(Sale.product_id == request.product_id)
        if request.region:
            query = query.filter(Sale.region == request.region)
        
        # Get last 24 months of data
        end_date = datetime.now().date()
        start_date = end_date - timedelta(days=730)
        query = query.filter(and_(Sale.sale_date >= start_date, Sale.sale_date <= end_date))
        
        # Aggregate by month
        monthly_data = query.with_entities(
            func.date_trunc('month', Sale.sale_date).label('month'),
            func.sum(Sale.total_amount).label('sales')
        ).group_by(func.date_trunc('month', Sale.sale_date)).order_by('month').all()
        
        if len(monthly_data) < 6:
            return SalesForecastResponse(
                forecast_data=[],
                confidence_intervals=[],
                model_accuracy=0.0,
                insights=["Insufficient data for forecasting. Need at least 6 months of data."]
            )
        
        # Prepare data for ML model
        df = pd.DataFrame(monthly_data, columns=['month', 'sales'])
        df['month'] = pd.to_datetime(df['month'])
        df['month_num'] = (df['month'] - df['month'].min()).dt.days / 30.44  # Convert to months
        
        # Simple linear regression for forecasting
        X = df['month_num'].values.reshape(-1, 1)
        y = df['sales'].values
        
        model = LinearRegression()
        model.fit(X, y)
        
        # Generate forecast
        last_month = df['month_num'].max()
        forecast_months = np.arange(last_month + 1, last_month + 1 + request.forecast_periods)
        forecast_values = model.predict(forecast_months.reshape(-1, 1))
        
        # Calculate confidence intervals (simplified)
        residuals = y - model.predict(X)
        std_error = np.std(residuals)
        confidence_multiplier = 1.96  # 95% confidence
        
        forecast_data = []
        confidence_intervals = []
        
        for i, (month_num, value) in enumerate(zip(forecast_months, forecast_values)):
            forecast_date = df['month'].min() + pd.DateOffset(months=int(month_num))
            forecast_data.append({
                "date": forecast_date.strftime("%Y-%m-%d"),
                "forecast": float(value),
                "month": i + 1
            })
            
            confidence_intervals.append({
                "date": forecast_date.strftime("%Y-%m-%d"),
                "lower": float(value - confidence_multiplier * std_error),
                "upper": float(value + confidence_multiplier * std_error),
                "month": i + 1
            })
        
        # Calculate model accuracy (R² score)
        model_accuracy = model.score(X, y)
        
        # Generate insights
        trend = "increasing" if model.coef_[0] > 0 else "decreasing"
        insights = [
            f"Sales trend is {trend} with a monthly change of ${model.coef_[0]:.2f}",
            f"Model accuracy (R²): {model_accuracy:.2%}",
            f"Forecast confidence: {request.confidence_level:.0%}"
        ]
        
        return SalesForecastResponse(
            forecast_data=forecast_data,
            confidence_intervals=confidence_intervals,
            model_accuracy=float(model_accuracy),
            insights=insights
        )

    def detect_anomalies(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None
    ) -> AnomalyDetectionResponse:
        # Get sales data
        query = self.db.query(Sale)
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            query = query.filter(Sale.sale_date <= end_date)
        if region:
            query = query.filter(Sale.region == region)
        
        # Get daily sales data
        daily_data = query.with_entities(
            Sale.sale_date,
            func.sum(Sale.total_amount).label('daily_sales'),
            func.count(Sale.id).label('daily_count')
        ).group_by(Sale.sale_date).order_by(Sale.sale_date).all()
        
        if len(daily_data) < 30:
            return AnomalyDetectionResponse(
                anomalies=[],
                total_anomalies=0,
                anomaly_rate=0.0,
                insights=["Insufficient data for anomaly detection. Need at least 30 days of data."]
            )
        
        # Prepare data for anomaly detection
        df = pd.DataFrame(daily_data, columns=['date', 'sales', 'count'])
        features = df[['sales', 'count']].values
        
        # Use Isolation Forest for anomaly detection
        iso_forest = IsolationForest(contamination=0.1, random_state=42)
        anomaly_labels = iso_forest.fit_predict(features)
        
        # Identify anomalies
        anomalies = []
        for i, (label, row) in enumerate(zip(anomaly_labels, df.itertuples())):
            if label == -1:  # Anomaly
                anomalies.append({
                    "date": row.date.strftime("%Y-%m-%d"),
                    "sales": float(row.sales),
                    "count": int(row.count),
                    "anomaly_score": float(iso_forest.decision_function([features[i]])[0])
                })
        
        total_anomalies = len(anomalies)
        anomaly_rate = total_anomalies / len(daily_data) * 100
        
        # Generate insights
        insights = [
            f"Detected {total_anomalies} anomalies out of {len(daily_data)} days ({anomaly_rate:.1f}%)",
            "Anomalies may indicate unusual sales patterns, data quality issues, or significant business events"
        ]
        
        if total_anomalies > 0:
            avg_anomaly_sales = np.mean([a['sales'] for a in anomalies])
            avg_normal_sales = np.mean([row.sales for i, row in enumerate(df.itertuples()) if anomaly_labels[i] == 1])
            insights.append(f"Average sales on anomaly days: ${avg_anomaly_sales:.2f} vs normal days: ${avg_normal_sales:.2f}")
        
        return AnomalyDetectionResponse(
            anomalies=anomalies,
            total_anomalies=total_anomalies,
            anomaly_rate=float(anomaly_rate),
            insights=insights
        )

    def process_natural_language_query(self, query_text: str, user_id: int) -> NaturalLanguageQueryResponse:
        # Store the query
        nl_query = NaturalLanguageQuery(
            query_text=query_text,
            user_id=user_id
        )
        self.db.add(nl_query)
        
        # Process the query using OpenAI (if available) or simple keyword matching
        if settings.OPENAI_API_KEY:
            response_data = self._process_with_openai(query_text)
        else:
            response_data = self._process_with_keywords(query_text)
        
        nl_query.response_data = response_data
        self.db.commit()
        
        return NaturalLanguageQueryResponse(
            query_text=query_text,
            response_data=response_data,
            created_at=nl_query.created_at
        )

    def _process_with_openai(self, query_text: str) -> Dict[str, Any]:
        try:
            # Get sales data summary for context
            sales_summary = self.get_sales_summary()
            
            prompt = f"""
            Based on the following sales data summary, answer the user's question: "{query_text}"
            
            Sales Data Summary:
            - Total Sales: ${sales_summary['total_sales']:,.2f}
            - Total Revenue: ${sales_summary['total_revenue']:,.2f}
            - Average Sale Amount: ${sales_summary['average_sale_amount']:,.2f}
            - Top Regions: {sales_summary['top_regions'][:3]}
            - Top Products: {sales_summary['top_products'][:3]}
            
            Provide a clear, data-driven answer with specific numbers and insights.
            """
            
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=500
            )
            
            return {
                "answer": response.choices[0].message.content,
                "data": sales_summary,
                "method": "openai"
            }
        except Exception as e:
            return self._process_with_keywords(query_text)

    def _process_with_keywords(self, query_text: str) -> Dict[str, Any]:
        query_lower = query_text.lower()
        sales_summary = self.get_sales_summary()
        
        if "top" in query_lower and "product" in query_lower:
            return {
                "answer": f"The top products by revenue are: {', '.join([p['product'] for p in sales_summary['top_products'][:5]])}",
                "data": {"top_products": sales_summary['top_products'][:5]},
                "method": "keyword_matching"
            }
        elif "top" in query_lower and "region" in query_lower:
            return {
                "answer": f"The top regions by revenue are: {', '.join([r['region'] for r in sales_summary['top_regions'][:5]])}",
                "data": {"top_regions": sales_summary['top_regions'][:5]},
                "method": "keyword_matching"
            }
        elif "total" in query_lower and "sales" in query_lower:
            return {
                "answer": f"Total sales revenue is ${sales_summary['total_revenue']:,.2f} from {sales_summary['total_sales']} transactions.",
                "data": {"total_revenue": sales_summary['total_revenue'], "total_sales": sales_summary['total_sales']},
                "method": "keyword_matching"
            }
        else:
            return {
                "answer": "I can help you analyze sales data. Try asking about top products, top regions, or total sales.",
                "data": sales_summary,
                "method": "keyword_matching"
            }

    def get_recent_insights(self, limit: int = 10) -> List[AnalyticsInsight]:
        return self.db.query(AnalyticsInsight).order_by(AnalyticsInsight.created_at.desc()).limit(limit).all()

    def get_sales_trends(
        self,
        period: str = "month",
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None
    ) -> Dict[str, Any]:
        query = self.db.query(Sale)
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            query = query.filter(Sale.sale_date <= end_date)
        if region:
            query = query.filter(Sale.region == region)
        
        if period == "day":
            date_trunc = func.date_trunc('day', Sale.sale_date)
        elif period == "week":
            date_trunc = func.date_trunc('week', Sale.sale_date)
        elif period == "month":
            date_trunc = func.date_trunc('month', Sale.sale_date)
        else:  # year
            date_trunc = func.date_trunc('year', Sale.sale_date)
        
        trends = query.with_entities(
            date_trunc.label('period'),
            func.sum(Sale.total_amount).label('sales'),
            func.count(Sale.id).label('count')
        ).group_by(date_trunc).order_by('period').all()
        
        return {
            "period": period,
            "data": [
                {
                    "period": trend.period.strftime("%Y-%m-%d"),
                    "sales": float(trend.sales),
                    "count": int(trend.count)
                }
                for trend in trends
            ]
        }

    def get_top_products(
        self,
        limit: int = 10,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        query = self.db.query(Sale).join(Product)
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            query = query.filter(Sale.sale_date <= end_date)
        if region:
            query = query.filter(Sale.region == region)
        
        top_products = query.with_entities(
            Product.name,
            Product.category,
            func.sum(Sale.total_amount).label('total_revenue'),
            func.sum(Sale.quantity).label('total_quantity'),
            func.count(Sale.id).label('total_sales')
        ).group_by(Product.name, Product.category).order_by(
            func.sum(Sale.total_amount).desc()
        ).limit(limit).all()
        
        return [
            {
                "name": product.name,
                "category": product.category,
                "total_revenue": float(product.total_revenue),
                "total_quantity": int(product.total_quantity),
                "total_sales": int(product.total_sales)
            }
            for product in top_products
        ]

    def get_sales_summary(self) -> Dict[str, Any]:
        # Get basic sales summary
        total_sales = self.db.query(Sale).count()
        total_revenue = self.db.query(Sale).with_entities(func.sum(Sale.total_amount)).scalar() or 0
        avg_sale_amount = self.db.query(Sale).with_entities(func.avg(Sale.total_amount)).scalar() or 0
        
        # Top regions
        top_regions = self.db.query(Sale).with_entities(
            Sale.region, 
            func.sum(Sale.total_amount).label('total')
        ).group_by(Sale.region).order_by(func.sum(Sale.total_amount).desc()).limit(5).all()
        
        # Top products
        top_products = self.db.query(Sale).join(Product).with_entities(
            Product.name,
            func.sum(Sale.total_amount).label('total')
        ).group_by(Product.name).order_by(func.sum(Sale.total_amount).desc()).limit(5).all()
        
        return {
            "total_sales": total_sales,
            "total_revenue": float(total_revenue),
            "average_sale_amount": float(avg_sale_amount),
            "top_regions": [{"region": r[0], "total": float(r[1])} for r in top_regions],
            "top_products": [{"product": p[0], "total": float(p[1])} for p in top_products]
        }
