from sqlalchemy.orm import Session, joinedload
from sqlalchemy import func, and_, or_
from typing import List, Optional, Dict, Any
from datetime import date, datetime
import pandas as pd
import io
from fastapi import UploadFile

from app.models.sale import Sale
from app.models.product import Product
from app.schemas.sale import SaleCreate, SaleUpdate, SalesUploadResponse

class SaleService:
    def __init__(self, db: Session):
        self.db = db

    def get_sale(self, sale_id: int) -> Optional[Sale]:
        return self.db.query(Sale).options(joinedload(Sale.product)).filter(Sale.id == sale_id).first()

    def get_sales(
        self, 
        skip: int = 0, 
        limit: int = 100,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None,
        product_id: Optional[int] = None
    ) -> List[Sale]:
        query = self.db.query(Sale).options(joinedload(Sale.product))
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            query = query.filter(Sale.sale_date <= end_date)
        if region:
            query = query.filter(Sale.region == region)
        if product_id:
            query = query.filter(Sale.product_id == product_id)
        
        return query.offset(skip).limit(limit).all()

    def create_sale(self, sale: SaleCreate) -> Sale:
        db_sale = Sale(**sale.dict())
        self.db.add(db_sale)
        self.db.commit()
        self.db.refresh(db_sale)
        return db_sale

    def update_sale(self, sale_id: int, sale_update: SaleUpdate) -> Optional[Sale]:
        db_sale = self.get_sale(sale_id)
        if not db_sale:
            return None
        
        update_data = sale_update.dict(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_sale, field, value)
        
        self.db.commit()
        self.db.refresh(db_sale)
        return db_sale

    def delete_sale(self, sale_id: int) -> bool:
        db_sale = self.get_sale(sale_id)
        if not db_sale:
            return False
        
        self.db.delete(db_sale)
        self.db.commit()
        return True

    async def upload_sales_data(self, file: UploadFile) -> SalesUploadResponse:
        content = await file.read()
        errors = []
        records_processed = 0
        records_successful = 0
        
        try:
            if file.filename.endswith('.csv'):
                df = pd.read_csv(io.StringIO(content.decode('utf-8')))
            else:  # Excel file
                df = pd.read_excel(io.BytesIO(content))
            
            records_processed = len(df)
            
            for index, row in df.iterrows():
                try:
                    # Validate and create sale record
                    sale_data = SaleCreate(
                        product_id=int(row.get('product_id', 0)),
                        quantity=int(row.get('quantity', 0)),
                        unit_price=float(row.get('unit_price', 0)),
                        total_amount=float(row.get('total_amount', 0)),
                        sale_date=pd.to_datetime(row.get('sale_date')).date(),
                        region=str(row.get('region', '')),
                        customer_name=str(row.get('customer_name', '')) if pd.notna(row.get('customer_name')) else None,
                        sales_rep=str(row.get('sales_rep', '')) if pd.notna(row.get('sales_rep')) else None
                    )
                    
                    self.create_sale(sale_data)
                    records_successful += 1
                    
                except Exception as e:
                    errors.append(f"Row {index + 1}: {str(e)}")
            
        except Exception as e:
            errors.append(f"File processing error: {str(e)}")
        
        return SalesUploadResponse(
            message=f"Upload completed. {records_successful} records processed successfully.",
            records_processed=records_processed,
            records_successful=records_successful,
            records_failed=len(errors),
            errors=errors if errors else None
        )

    def get_sales_summary(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None,
        product_id: Optional[int] = None
    ) -> Dict[str, Any]:
        query = self.db.query(Sale)
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            query = query.filter(Sale.sale_date <= end_date)
        if region:
            query = query.filter(Sale.region == region)
        if product_id:
            query = query.filter(Sale.product_id == product_id)
        
        # Calculate summary statistics
        total_sales = query.count()
        total_revenue = query.with_entities(func.sum(Sale.total_amount)).scalar() or 0
        avg_sale_amount = query.with_entities(func.avg(Sale.total_amount)).scalar() or 0
        
        # Top regions
        top_regions = query.with_entities(
            Sale.region, 
            func.sum(Sale.total_amount).label('total')
        ).group_by(Sale.region).order_by(func.sum(Sale.total_amount).desc()).limit(5).all()
        
        # Top products
        top_products = query.join(Product).with_entities(
            Product.name,
            func.sum(Sale.total_amount).label('total')
        ).group_by(Product.name).order_by(func.sum(Sale.total_amount).desc()).limit(5).all()
        
        return {
            "total_sales": total_sales,
            "total_revenue": float(total_revenue),
            "average_sale_amount": float(avg_sale_amount),
            "top_regions": [{"region": r[0], "total": float(r[1])} for r in top_regions],
            "top_products": [{"product": p[0], "total": float(p[1])} for p in top_products]
        }
