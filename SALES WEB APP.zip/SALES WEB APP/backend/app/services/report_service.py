from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import Optional, Dict, Any
from datetime import date
import pandas as pd
import io
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch

from app.models.sale import Sale
from app.models.product import Product

class ReportService:
    def __init__(self, db: Session):
        self.db = db

    def generate_profit_loss_report(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None,
        product_id: Optional[int] = None
    ) -> Dict[str, Any]:
        query = self.db.query(Sale).join(Product)
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            query = query.filter(Sale.sale_date <= end_date)
        if region:
            query = query.filter(Sale.region == region)
        if product_id:
            query = query.filter(Sale.product_id == product_id)
        
        # Calculate revenue and costs
        sales_data = query.with_entities(
            Sale.total_amount,
            Product.cost_price,
            Sale.quantity,
            Product.name,
            Sale.region
        ).all()
        
        total_revenue = sum(sale.total_amount for sale in sales_data)
        total_costs = sum(sale.cost_price * sale.quantity for sale in sales_data)
        gross_profit = total_revenue - total_costs
        profit_margin = (gross_profit / total_revenue * 100) if total_revenue > 0 else 0
        
        # Product-wise breakdown
        product_breakdown = {}
        for sale in sales_data:
            product_name = sale.name
            if product_name not in product_breakdown:
                product_breakdown[product_name] = {
                    "revenue": 0,
                    "costs": 0,
                    "quantity": 0
                }
            product_breakdown[product_name]["revenue"] += sale.total_amount
            product_breakdown[product_name]["costs"] += sale.cost_price * sale.quantity
            product_breakdown[product_name]["quantity"] += sale.quantity
        
        # Calculate profit for each product
        for product in product_breakdown.values():
            product["profit"] = product["revenue"] - product["costs"]
            product["margin"] = (product["profit"] / product["revenue"] * 100) if product["revenue"] > 0 else 0
        
        # Region-wise breakdown
        region_breakdown = {}
        for sale in sales_data:
            region_name = sale.region
            if region_name not in region_breakdown:
                region_breakdown[region_name] = {
                    "revenue": 0,
                    "costs": 0,
                    "quantity": 0
                }
            region_breakdown[region_name]["revenue"] += sale.total_amount
            region_breakdown[region_name]["costs"] += sale.cost_price * sale.quantity
            region_breakdown[region_name]["quantity"] += sale.quantity
        
        # Calculate profit for each region
        for region in region_breakdown.values():
            region["profit"] = region["revenue"] - region["costs"]
            region["margin"] = (region["profit"] / region["revenue"] * 100) if region["revenue"] > 0 else 0
        
        return {
            "period": {
                "start_date": start_date.isoformat() if start_date else None,
                "end_date": end_date.isoformat() if end_date else None
            },
            "summary": {
                "total_revenue": float(total_revenue),
                "total_costs": float(total_costs),
                "gross_profit": float(gross_profit),
                "profit_margin": float(profit_margin)
            },
            "product_breakdown": product_breakdown,
            "region_breakdown": region_breakdown,
            "filters": {
                "region": region,
                "product_id": product_id
            }
        }

    def generate_sales_summary_report(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None,
        product_id: Optional[int] = None
    ) -> Dict[str, Any]:
        query = self.db.query(Sale).join(Product)
        
        if start_date:
            query = query.filter(Sale.sale_date >= start_date)
        if end_date:
            query = query.filter(Sale.sale_date <= end_date)
        if region:
            query = query.filter(Sale.region == region)
        if product_id:
            query = query.filter(Sale.product_id == product_id)
        
        # Basic metrics
        total_sales = query.count()
        total_revenue = query.with_entities(func.sum(Sale.total_amount)).scalar() or 0
        avg_sale_amount = query.with_entities(func.avg(Sale.total_amount)).scalar() or 0
        
        # Daily sales trend
        daily_sales = query.with_entities(
            Sale.sale_date,
            func.sum(Sale.total_amount).label('daily_revenue'),
            func.count(Sale.id).label('daily_count')
        ).group_by(Sale.sale_date).order_by(Sale.sale_date).all()
        
        # Top products
        top_products = query.with_entities(
            Product.name,
            func.sum(Sale.total_amount).label('revenue'),
            func.sum(Sale.quantity).label('quantity'),
            func.count(Sale.id).label('sales_count')
        ).group_by(Product.name).order_by(func.sum(Sale.total_amount).desc()).limit(10).all()
        
        # Top regions
        top_regions = query.with_entities(
            Sale.region,
            func.sum(Sale.total_amount).label('revenue'),
            func.count(Sale.id).label('sales_count')
        ).group_by(Sale.region).order_by(func.sum(Sale.total_amount).desc()).limit(10).all()
        
        # Sales by month
        monthly_sales = query.with_entities(
            func.date_trunc('month', Sale.sale_date).label('month'),
            func.sum(Sale.total_amount).label('revenue'),
            func.count(Sale.id).label('sales_count')
        ).group_by(func.date_trunc('month', Sale.sale_date)).order_by('month').all()
        
        return {
            "period": {
                "start_date": start_date.isoformat() if start_date else None,
                "end_date": end_date.isoformat() if end_date else None
            },
            "summary": {
                "total_sales": total_sales,
                "total_revenue": float(total_revenue),
                "average_sale_amount": float(avg_sale_amount)
            },
            "daily_trend": [
                {
                    "date": sale.sale_date.isoformat(),
                    "revenue": float(sale.daily_revenue),
                    "count": int(sale.daily_count)
                }
                for sale in daily_sales
            ],
            "top_products": [
                {
                    "name": product.name,
                    "revenue": float(product.revenue),
                    "quantity": int(product.quantity),
                    "sales_count": int(product.sales_count)
                }
                for product in top_products
            ],
            "top_regions": [
                {
                    "region": region.region,
                    "revenue": float(region.revenue),
                    "sales_count": int(region.sales_count)
                }
                for region in top_regions
            ],
            "monthly_trend": [
                {
                    "month": sale.month.strftime("%Y-%m"),
                    "revenue": float(sale.revenue),
                    "sales_count": int(sale.sales_count)
                }
                for sale in monthly_sales
            ],
            "filters": {
                "region": region,
                "product_id": product_id
            }
        }

    def generate_pdf_profit_loss_report(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None,
        product_id: Optional[int] = None
    ) -> bytes:
        # Get report data
        report_data = self.generate_profit_loss_report(start_date, end_date, region, product_id)
        
        # Create PDF
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        styles = getSampleStyleSheet()
        story = []
        
        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=1  # Center alignment
        )
        story.append(Paragraph("Profit & Loss Report", title_style))
        story.append(Spacer(1, 12))
        
        # Period
        period_text = f"Period: {report_data['period']['start_date']} to {report_data['period']['end_date']}" if report_data['period']['start_date'] else "Period: All time"
        story.append(Paragraph(period_text, styles['Normal']))
        story.append(Spacer(1, 12))
        
        # Summary table
        summary_data = [
            ['Metric', 'Amount'],
            ['Total Revenue', f"${report_data['summary']['total_revenue']:,.2f}"],
            ['Total Costs', f"${report_data['summary']['total_costs']:,.2f}"],
            ['Gross Profit', f"${report_data['summary']['gross_profit']:,.2f}"],
            ['Profit Margin', f"{report_data['summary']['profit_margin']:.2f}%"]
        ]
        
        summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(summary_table)
        story.append(Spacer(1, 20))
        
        # Product breakdown
        story.append(Paragraph("Product Breakdown", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        product_data = [['Product', 'Revenue', 'Costs', 'Profit', 'Margin']]
        for product, data in report_data['product_breakdown'].items():
            product_data.append([
                product,
                f"${data['revenue']:,.2f}",
                f"${data['costs']:,.2f}",
                f"${data['profit']:,.2f}",
                f"{data['margin']:.2f}%"
            ])
        
        product_table = Table(product_data, colWidths=[2*inch, 1.5*inch, 1.5*inch, 1.5*inch, 1*inch])
        product_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(product_table)
        
        # Build PDF
        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()

    def generate_excel_profit_loss_report(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None,
        product_id: Optional[int] = None
    ) -> bytes:
        # Get report data
        report_data = self.generate_profit_loss_report(start_date, end_date, region, product_id)
        
        # Create Excel file
        buffer = io.BytesIO()
        with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
            # Summary sheet
            summary_df = pd.DataFrame([
                ['Total Revenue', report_data['summary']['total_revenue']],
                ['Total Costs', report_data['summary']['total_costs']],
                ['Gross Profit', report_data['summary']['gross_profit']],
                ['Profit Margin', report_data['summary']['profit_margin']]
            ], columns=['Metric', 'Amount'])
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            
            # Product breakdown sheet
            product_df = pd.DataFrame([
                {
                    'Product': product,
                    'Revenue': data['revenue'],
                    'Costs': data['costs'],
                    'Profit': data['profit'],
                    'Margin': data['margin']
                }
                for product, data in report_data['product_breakdown'].items()
            ])
            product_df.to_excel(writer, sheet_name='Product Breakdown', index=False)
            
            # Region breakdown sheet
            region_df = pd.DataFrame([
                {
                    'Region': region,
                    'Revenue': data['revenue'],
                    'Costs': data['costs'],
                    'Profit': data['profit'],
                    'Margin': data['margin']
                }
                for region, data in report_data['region_breakdown'].items()
            ])
            region_df.to_excel(writer, sheet_name='Region Breakdown', index=False)
        
        buffer.seek(0)
        return buffer.getvalue()

    def generate_pdf_sales_summary_report(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None,
        product_id: Optional[int] = None
    ) -> bytes:
        # Get report data
        report_data = self.generate_sales_summary_report(start_date, end_date, region, product_id)
        
        # Create PDF (similar structure to profit loss report)
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        styles = getSampleStyleSheet()
        story = []
        
        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=18,
            spaceAfter=30,
            alignment=1
        )
        story.append(Paragraph("Sales Summary Report", title_style))
        story.append(Spacer(1, 12))
        
        # Summary table
        summary_data = [
            ['Metric', 'Value'],
            ['Total Sales', str(report_data['summary']['total_sales'])],
            ['Total Revenue', f"${report_data['summary']['total_revenue']:,.2f}"],
            ['Average Sale Amount', f"${report_data['summary']['average_sale_amount']:,.2f}"]
        ]
        
        summary_table = Table(summary_data, colWidths=[3*inch, 2*inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 14),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(summary_table)
        story.append(Spacer(1, 20))
        
        # Top products
        story.append(Paragraph("Top Products", styles['Heading2']))
        story.append(Spacer(1, 12))
        
        product_data = [['Product', 'Revenue', 'Quantity', 'Sales Count']]
        for product in report_data['top_products'][:10]:
            product_data.append([
                product['name'],
                f"${product['revenue']:,.2f}",
                str(product['quantity']),
                str(product['sales_count'])
            ])
        
        product_table = Table(product_data, colWidths=[2*inch, 1.5*inch, 1*inch, 1*inch])
        product_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        story.append(product_table)
        
        # Build PDF
        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()

    def generate_excel_sales_summary_report(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        region: Optional[str] = None,
        product_id: Optional[int] = None
    ) -> bytes:
        # Get report data
        report_data = self.generate_sales_summary_report(start_date, end_date, region, product_id)
        
        # Create Excel file
        buffer = io.BytesIO()
        with pd.ExcelWriter(buffer, engine='openpyxl') as writer:
            # Summary sheet
            summary_df = pd.DataFrame([
                ['Total Sales', report_data['summary']['total_sales']],
                ['Total Revenue', report_data['summary']['total_revenue']],
                ['Average Sale Amount', report_data['summary']['average_sale_amount']]
            ], columns=['Metric', 'Value'])
            summary_df.to_excel(writer, sheet_name='Summary', index=False)
            
            # Top products sheet
            products_df = pd.DataFrame(report_data['top_products'])
            products_df.to_excel(writer, sheet_name='Top Products', index=False)
            
            # Top regions sheet
            regions_df = pd.DataFrame(report_data['top_regions'])
            regions_df.to_excel(writer, sheet_name='Top Regions', index=False)
            
            # Daily trend sheet
            daily_df = pd.DataFrame(report_data['daily_trend'])
            daily_df.to_excel(writer, sheet_name='Daily Trend', index=False)
            
            # Monthly trend sheet
            monthly_df = pd.DataFrame(report_data['monthly_trend'])
            monthly_df.to_excel(writer, sheet_name='Monthly Trend', index=False)
        
        buffer.seek(0)
        return buffer.getvalue()
