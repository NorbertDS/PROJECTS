#!/usr/bin/env python3
"""
Simple Sales Analytics Server
This is a minimal demonstration of the sales analytics application
"""

import json
from datetime import datetime, date
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import threading
import webbrowser
import time

# Sample data
SAMPLE_SALES = [
    {
        "id": 1,
        "product_id": 1,
        "quantity": 2,
        "unit_price": 1299.99,
        "total_amount": 2599.98,
        "sale_date": "2024-01-15",
        "region": "North",
        "customer_name": "John Smith"
    },
    {
        "id": 2,
        "product_id": 2,
        "quantity": 5,
        "unit_price": 49.99,
        "total_amount": 249.95,
        "sale_date": "2024-01-16",
        "region": "North",
        "customer_name": "Jane Doe"
    },
    {
        "id": 3,
        "product_id": 3,
        "quantity": 1,
        "unit_price": 299.99,
        "total_amount": 299.99,
        "sale_date": "2024-02-10",
        "region": "South",
        "customer_name": "Bob Wilson"
    },
    {
        "id": 4,
        "product_id": 4,
        "quantity": 1,
        "unit_price": 599.99,
        "total_amount": 599.99,
        "sale_date": "2024-02-11",
        "region": "East",
        "customer_name": "Sarah Davis"
    },
    {
        "id": 5,
        "product_id": 5,
        "quantity": 3,
        "unit_price": 89.99,
        "total_amount": 269.97,
        "sale_date": "2024-03-05",
        "region": "West",
        "customer_name": "Tom Anderson"
    }
]

SAMPLE_PRODUCTS = [
    {"id": 1, "name": "Laptop Pro 15\"", "category": "Electronics", "unit_price": 1299.99, "cost_price": 800.00},
    {"id": 2, "name": "Wireless Mouse", "category": "Electronics", "unit_price": 49.99, "cost_price": 25.00},
    {"id": 3, "name": "Office Chair", "category": "Furniture", "unit_price": 299.99, "cost_price": 150.00},
    {"id": 4, "name": "Standing Desk", "category": "Furniture", "unit_price": 599.99, "cost_price": 300.00},
    {"id": 5, "name": "Coffee Maker", "category": "Appliances", "unit_price": 89.99, "cost_price": 45.00},
]

class SalesAnalyticsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Add CORS headers
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
        
        if path == '/':
            response = {
                "message": "Sales Analytics API",
                "status": "running",
                "timestamp": datetime.now().isoformat(),
                "endpoints": [
                    "/api/sales/",
                    "/api/products/",
                    "/api/analytics/kpi",
                    "/api/analytics/trends/sales"
                ]
            }
        elif path == '/health':
            response = {"status": "healthy", "timestamp": datetime.now().isoformat()}
        elif path == '/api/sales/':
            response = SAMPLE_SALES
        elif path == '/api/products/':
            response = SAMPLE_PRODUCTS
        elif path == '/api/analytics/kpi':
            total_revenue = sum(sale['total_amount'] for sale in SAMPLE_SALES)
            total_transactions = len(SAMPLE_SALES)
            average_sale = total_revenue / total_transactions if total_transactions > 0 else 0
            
            response = {
                "total_sales": total_revenue,
                "total_revenue": total_revenue,
                "average_sale_amount": average_sale,
                "total_transactions": total_transactions,
                "profit_margin": 25.5,  # Mock data
                "sales_growth": 15.2,   # Mock data
                "top_product": "Laptop Pro 15\"",
                "top_region": "North",
                "period": "All time"
            }
        elif path == '/api/analytics/trends/sales':
            # Group sales by month
            monthly_data = {}
            for sale in SAMPLE_SALES:
                month = sale['sale_date'][:7]  # YYYY-MM
                if month not in monthly_data:
                    monthly_data[month] = {"sales": 0, "count": 0}
                monthly_data[month]["sales"] += sale['total_amount']
                monthly_data[month]["count"] += 1
            
            response = {
                "period": "month",
                "data": [
                    {
                        "period": f"{month}-01",
                        "sales": data["sales"],
                        "count": data["count"]
                    }
                    for month, data in sorted(monthly_data.items())
                ]
            }
        else:
            response = {"error": "Endpoint not found", "path": path}
        
        self.wfile.write(json.dumps(response, indent=2).encode())
    
    def do_OPTIONS(self):
        # Handle CORS preflight requests
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
    
    def log_message(self, format, *args):
        # Suppress default logging
        pass

def start_server():
    server = HTTPServer(('localhost', 8000), SalesAnalyticsHandler)
    print("🚀 Sales Analytics Server Starting...")
    print("📊 API Server: http://localhost:8000")
    print("🔍 Health Check: http://localhost:8000/health")
    print("📈 Sales Data: http://localhost:8000/api/sales/")
    print("📦 Products: http://localhost:8000/api/products/")
    print("📊 KPI Metrics: http://localhost:8000/api/analytics/kpi")
    print("📈 Sales Trends: http://localhost:8000/api/analytics/trends/sales")
    print("\n✅ Server is running! Press Ctrl+C to stop.")
    print("🌐 Open your browser and visit: http://localhost:8000")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server stopped.")
        server.shutdown()

if __name__ == "__main__":
    start_server()
