from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer
from sqlalchemy import create_engine, Column, Integer, String, Float, Date, DateTime, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from pydantic import BaseModel
from datetime import datetime, date
from typing import List, Optional
import uvicorn

# SQLite database setup
SQLALCHEMY_DATABASE_URL = "sqlite:///./sales_analytics.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Simple models
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    full_name = Column(String)
    role = Column(String, default="viewer")

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    category = Column(String)
    unit_price = Column(Float)
    cost_price = Column(Float)

class Sale(Base):
    __tablename__ = "sales"
    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer)
    quantity = Column(Integer)
    unit_price = Column(Float)
    total_amount = Column(Float)
    sale_date = Column(Date)
    region = Column(String)
    customer_name = Column(String)

# Create tables
Base.metadata.create_all(bind=engine)

# Pydantic models
class SaleCreate(BaseModel):
    product_id: int
    quantity: int
    unit_price: float
    total_amount: float
    sale_date: date
    region: str
    customer_name: Optional[str] = None

class SaleResponse(BaseModel):
    id: int
    product_id: int
    quantity: int
    unit_price: float
    total_amount: float
    sale_date: date
    region: str
    customer_name: Optional[str] = None

    class Config:
        from_attributes = True

class KPIMetrics(BaseModel):
    total_sales: float
    total_revenue: float
    average_sale: float
    total_transactions: int

# FastAPI app
app = FastAPI(title="Sales Analytics API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Routes
@app.get("/")
async def root():
    return {"message": "Sales Analytics API", "status": "running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now()}

@app.post("/api/sales/", response_model=SaleResponse)
async def create_sale(sale: SaleCreate, db: Session = Depends(get_db)):
    db_sale = Sale(**sale.dict())
    db.add(db_sale)
    db.commit()
    db.refresh(db_sale)
    return db_sale

@app.get("/api/sales/", response_model=List[SaleResponse])
async def get_sales(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    sales = db.query(Sale).offset(skip).limit(limit).all()
    return sales

@app.get("/api/analytics/kpi", response_model=KPIMetrics)
async def get_kpi_metrics(db: Session = Depends(get_db)):
    total_revenue = db.query(func.sum(Sale.total_amount)).scalar() or 0
    total_transactions = db.query(func.count(Sale.id)).scalar() or 0
    average_sale = total_revenue / total_transactions if total_transactions > 0 else 0
    
    return KPIMetrics(
        total_sales=total_revenue,
        total_revenue=total_revenue,
        average_sale=average_sale,
        total_transactions=total_transactions
    )

@app.get("/api/analytics/trends/sales")
async def get_sales_trends(db: Session = Depends(get_db)):
    # Simple monthly aggregation
    trends = db.query(
        func.date_trunc('month', Sale.sale_date).label('month'),
        func.sum(Sale.total_amount).label('sales'),
        func.count(Sale.id).label('count')
    ).group_by(func.date_trunc('month', Sale.sale_date)).all()
    
    return {
        "period": "month",
        "data": [
            {
                "period": trend.month.strftime("%Y-%m-%d"),
                "sales": float(trend.sales),
                "count": int(trend.count)
            }
            for trend in trends
        ]
    }

# Initialize with sample data
@app.on_event("startup")
async def startup_event():
    db = SessionLocal()
    
    # Check if we already have data
    if db.query(Sale).count() == 0:
        # Add sample products
        sample_products = [
            Product(name="Laptop Pro 15\"", category="Electronics", unit_price=1299.99, cost_price=800.00),
            Product(name="Wireless Mouse", category="Electronics", unit_price=49.99, cost_price=25.00),
            Product(name="Office Chair", category="Furniture", unit_price=299.99, cost_price=150.00),
            Product(name="Standing Desk", category="Furniture", unit_price=599.99, cost_price=300.00),
            Product(name="Coffee Maker", category="Appliances", unit_price=89.99, cost_price=45.00),
        ]
        
        for product in sample_products:
            db.add(product)
        
        # Add sample sales
        sample_sales = [
            Sale(product_id=1, quantity=2, unit_price=1299.99, total_amount=2599.98, 
                 sale_date=date(2024, 1, 15), region="North", customer_name="John Smith"),
            Sale(product_id=2, quantity=5, unit_price=49.99, total_amount=249.95, 
                 sale_date=date(2024, 1, 16), region="North", customer_name="Jane Doe"),
            Sale(product_id=3, quantity=1, unit_price=299.99, total_amount=299.99, 
                 sale_date=date(2024, 2, 10), region="South", customer_name="Bob Wilson"),
            Sale(product_id=4, quantity=1, unit_price=599.99, total_amount=599.99, 
                 sale_date=date(2024, 2, 11), region="East", customer_name="Sarah Davis"),
            Sale(product_id=5, quantity=3, unit_price=89.99, total_amount=269.97, 
                 sale_date=date(2024, 3, 5), region="West", customer_name="Tom Anderson"),
        ]
        
        for sale in sample_sales:
            db.add(sale)
        
        db.commit()
        print("✅ Sample data loaded successfully!")
    
    db.close()

if __name__ == "__main__":
    print("🚀 Starting Sales Analytics API...")
    print("📊 API will be available at: http://localhost:8000")
    print("📖 API Documentation: http://localhost:8000/docs")
    uvicorn.run(app, host="0.0.0.0", port=8000)
