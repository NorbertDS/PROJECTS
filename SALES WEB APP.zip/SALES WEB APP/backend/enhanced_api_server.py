#!/usr/bin/env python3
"""
Professional Sales Analytics API Server
A comprehensive FastAPI-based backend for the Sales Analytics Dashboard
"""

from fastapi import FastAPI, HTTPException, Depends, status, UploadFile, File
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, EmailStr
from typing import List, Optional, Dict, Any
import uvicorn
import json
import os
import hashlib
import jwt
from datetime import datetime, timedelta
import pandas as pd
import io
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Sales Analytics API",
    description="Professional Sales Analytics Dashboard Backend API",
    version="2.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# Security
security = HTTPBearer()

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configuration
SECRET_KEY = "your-secret-key-change-in-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# In-memory data storage (replace with database in production)
users_db = {
    "admin@example.com": {
        "id": 1,
        "email": "admin@example.com",
        "name": "Admin User",
        "role": "admin",
        "hashed_password": hashlib.sha256("admin123".encode()).hexdigest(),
        "is_active": True,
        "created_at": "2024-01-01T00:00:00Z"
    },
    "analyst@example.com": {
        "id": 2,
        "email": "analyst@example.com",
        "name": "Analyst User",
        "role": "analyst",
        "hashed_password": hashlib.sha256("analyst123".encode()).hexdigest(),
        "is_active": True,
        "created_at": "2024-01-01T00:00:00Z"
    },
    "viewer@example.com": {
        "id": 3,
        "email": "viewer@example.com",
        "name": "Viewer User",
        "role": "viewer",
        "hashed_password": hashlib.sha256("viewer123".encode()).hexdigest(),
        "is_active": True,
        "created_at": "2024-01-01T00:00:00Z"
    }
}

# Sample data
sales_data = [
    {
        "id": 1,
        "product_id": 1,
        "quantity": 2,
        "unit_price": 1200.00,
        "total_amount": 2400.00,
        "sale_date": "2024-01-15",
        "customer_name": "John Doe",
        "region": "North",
        "salesperson": "Alice Johnson"
    },
    {
        "id": 2,
        "product_id": 2,
        "quantity": 1,
        "unit_price": 800.00,
        "total_amount": 800.00,
        "sale_date": "2024-01-16",
        "customer_name": "Jane Smith",
        "region": "South",
        "salesperson": "Bob Wilson"
    }
]

products_data = [
    {
        "id": 1,
        "name": "Laptop Pro 15",
        "category": "Electronics",
        "unit_price": 1200.00,
        "cost_price": 800.00,
        "stock_quantity": 50,
        "description": "High-performance laptop for professionals",
        "created_at": "2024-01-01T00:00:00Z"
    },
    {
        "id": 2,
        "name": "Wireless Mouse",
        "category": "Accessories",
        "unit_price": 800.00,
        "cost_price": 400.00,
        "stock_quantity": 100,
        "description": "Ergonomic wireless mouse",
        "created_at": "2024-01-01T00:00:00Z"
    }
]

# Pydantic Models
class UserLogin(BaseModel):
    email: EmailStr
    password: str

class UserResponse(BaseModel):
    id: int
    email: str
    name: str
    role: str
    is_active: bool
    created_at: str

class Token(BaseModel):
    access_token: str
    token_type: str
    expires_in: int

class SaleCreate(BaseModel):
    product_id: int
    quantity: int
    unit_price: float
    sale_date: str
    customer_name: str
    region: str
    salesperson: str

class SaleResponse(BaseModel):
    id: int
    product_id: int
    quantity: int
    unit_price: float
    total_amount: float
    sale_date: str
    customer_name: str
    region: str
    salesperson: str

class ProductCreate(BaseModel):
    name: str
    category: str
    unit_price: float
    cost_price: float
    stock_quantity: int
    description: str

class ProductResponse(BaseModel):
    id: int
    name: str
    category: str
    unit_price: float
    cost_price: float
    stock_quantity: int
    description: str
    created_at: str

class KPIMetrics(BaseModel):
    total_revenue: float
    total_sales: int
    total_products: int
    average_order_value: float
    top_selling_product: str
    revenue_growth: float

# Utility Functions
def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return email
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

def get_current_user(email: str = Depends(verify_token)):
    user = users_db.get(email)
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return user

def check_permission(user: dict, required_role: str = None, action: str = None):
    """Check if user has permission for specific action"""
    if user["role"] == "admin":
        return True
    elif user["role"] == "analyst":
        return action in ["read", "create", "update"]
    elif user["role"] == "viewer":
        return action == "read"
    return False

# API Routes

@app.get("/", response_class=JSONResponse)
async def root():
    """Root endpoint with API information"""
    return {
        "message": "Sales Analytics API",
        "version": "2.0.0",
        "status": "operational",
        "documentation": "/api/docs",
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/api/health", response_class=JSONResponse)
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "2.0.0",
        "uptime": "operational"
    }

# Authentication Routes
@app.post("/api/auth/login", response_model=Token)
async def login(user_credentials: UserLogin):
    """Authenticate user and return access token"""
    user = users_db.get(user_credentials.email)
    
    if not user or not user["is_active"]:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    # Verify password
    hashed_password = hashlib.sha256(user_credentials.password.encode()).hexdigest()
    if hashed_password != user["hashed_password"]:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    # Create access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={"sub": user["email"], "role": user["role"]},
        expires_delta=access_token_expires
    )
    
    logger.info(f"User {user['email']} logged in successfully")
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in": ACCESS_TOKEN_EXPIRE_MINUTES * 60
    }

@app.get("/api/auth/me", response_model=UserResponse)
async def get_current_user_info(current_user: dict = Depends(get_current_user)):
    """Get current user information"""
    return UserResponse(**current_user)

@app.post("/api/auth/logout")
async def logout(current_user: dict = Depends(get_current_user)):
    """Logout user (client-side token removal)"""
    logger.info(f"User {current_user['email']} logged out")
    return {"message": "Successfully logged out"}

# Sales Routes
@app.get("/api/sales/", response_model=List[SaleResponse])
async def get_sales(
    skip: int = 0,
    limit: int = 100,
    current_user: dict = Depends(get_current_user)
):
    """Get all sales with pagination"""
    if not check_permission(current_user, action="read"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    return sales_data[skip:skip + limit]

@app.get("/api/sales/{sale_id}", response_model=SaleResponse)
async def get_sale(
    sale_id: int,
    current_user: dict = Depends(get_current_user)
):
    """Get specific sale by ID"""
    if not check_permission(current_user, action="read"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    sale = next((s for s in sales_data if s["id"] == sale_id), None)
    if not sale:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sale not found"
        )
    
    return sale

@app.post("/api/sales/", response_model=SaleResponse)
async def create_sale(
    sale: SaleCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create new sale"""
    if not check_permission(current_user, action="create"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    new_id = max([s["id"] for s in sales_data], default=0) + 1
    total_amount = sale.quantity * sale.unit_price
    
    new_sale = {
        "id": new_id,
        "product_id": sale.product_id,
        "quantity": sale.quantity,
        "unit_price": sale.unit_price,
        "total_amount": total_amount,
        "sale_date": sale.sale_date,
        "customer_name": sale.customer_name,
        "region": sale.region,
        "salesperson": sale.salesperson
    }
    
    sales_data.append(new_sale)
    logger.info(f"Sale {new_id} created by {current_user['email']}")
    
    return new_sale

@app.put("/api/sales/{sale_id}", response_model=SaleResponse)
async def update_sale(
    sale_id: int,
    sale_update: SaleCreate,
    current_user: dict = Depends(get_current_user)
):
    """Update existing sale"""
    if not check_permission(current_user, action="update"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    sale_index = next((i for i, s in enumerate(sales_data) if s["id"] == sale_id), None)
    if sale_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sale not found"
        )
    
    total_amount = sale_update.quantity * sale_update.unit_price
    sales_data[sale_index].update({
        "product_id": sale_update.product_id,
        "quantity": sale_update.quantity,
        "unit_price": sale_update.unit_price,
        "total_amount": total_amount,
        "sale_date": sale_update.sale_date,
        "customer_name": sale_update.customer_name,
        "region": sale_update.region,
        "salesperson": sale_update.salesperson
    })
    
    logger.info(f"Sale {sale_id} updated by {current_user['email']}")
    return sales_data[sale_index]

@app.delete("/api/sales/{sale_id}")
async def delete_sale(
    sale_id: int,
    current_user: dict = Depends(get_current_user)
):
    """Delete sale"""
    if not check_permission(current_user, action="delete"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can delete sales"
        )
    
    sale_index = next((i for i, s in enumerate(sales_data) if s["id"] == sale_id), None)
    if sale_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Sale not found"
        )
    
    deleted_sale = sales_data.pop(sale_index)
    logger.info(f"Sale {sale_id} deleted by {current_user['email']}")
    
    return {"message": "Sale deleted successfully", "deleted_sale": deleted_sale}

# Products Routes
@app.get("/api/products/", response_model=List[ProductResponse])
async def get_products(
    skip: int = 0,
    limit: int = 100,
    current_user: dict = Depends(get_current_user)
):
    """Get all products with pagination"""
    if not check_permission(current_user, action="read"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    return products_data[skip:skip + limit]

@app.get("/api/products/{product_id}", response_model=ProductResponse)
async def get_product(
    product_id: int,
    current_user: dict = Depends(get_current_user)
):
    """Get specific product by ID"""
    if not check_permission(current_user, action="read"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    product = next((p for p in products_data if p["id"] == product_id), None)
    if not product:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found"
        )
    
    return product

@app.post("/api/products/", response_model=ProductResponse)
async def create_product(
    product: ProductCreate,
    current_user: dict = Depends(get_current_user)
):
    """Create new product"""
    if not check_permission(current_user, action="create"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    new_id = max([p["id"] for p in products_data], default=0) + 1
    
    new_product = {
        "id": new_id,
        "name": product.name,
        "category": product.category,
        "unit_price": product.unit_price,
        "cost_price": product.cost_price,
        "stock_quantity": product.stock_quantity,
        "description": product.description,
        "created_at": datetime.utcnow().isoformat()
    }
    
    products_data.append(new_product)
    logger.info(f"Product {new_id} created by {current_user['email']}")
    
    return new_product

@app.put("/api/products/{product_id}", response_model=ProductResponse)
async def update_product(
    product_id: int,
    product_update: ProductCreate,
    current_user: dict = Depends(get_current_user)
):
    """Update existing product"""
    if not check_permission(current_user, action="update"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    product_index = next((i for i, p in enumerate(products_data) if p["id"] == product_id), None)
    if product_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found"
        )
    
    products_data[product_index].update({
        "name": product_update.name,
        "category": product_update.category,
        "unit_price": product_update.unit_price,
        "cost_price": product_update.cost_price,
        "stock_quantity": product_update.stock_quantity,
        "description": product_update.description
    })
    
    logger.info(f"Product {product_id} updated by {current_user['email']}")
    return products_data[product_index]

@app.delete("/api/products/{product_id}")
async def delete_product(
    product_id: int,
    current_user: dict = Depends(get_current_user)
):
    """Delete product"""
    if not check_permission(current_user, action="delete"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admins can delete products"
        )
    
    # Check if product is used in sales
    is_used = any(sale["product_id"] == product_id for sale in sales_data)
    if is_used:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete product that has sales records"
        )
    
    product_index = next((i for i, p in enumerate(products_data) if p["id"] == product_id), None)
    if product_index is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Product not found"
        )
    
    deleted_product = products_data.pop(product_index)
    logger.info(f"Product {product_id} deleted by {current_user['email']}")
    
    return {"message": "Product deleted successfully", "deleted_product": deleted_product}

# Analytics Routes
@app.get("/api/analytics/kpi", response_model=KPIMetrics)
async def get_kpi_metrics(current_user: dict = Depends(get_current_user)):
    """Get KPI metrics for dashboard"""
    if not check_permission(current_user, action="read"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    total_revenue = sum(sale["total_amount"] for sale in sales_data)
    total_sales = len(sales_data)
    total_products = len(products_data)
    average_order_value = total_revenue / total_sales if total_sales > 0 else 0
    
    # Find top selling product
    product_sales = {}
    for sale in sales_data:
        product_id = sale["product_id"]
        product_sales[product_id] = product_sales.get(product_id, 0) + sale["quantity"]
    
    top_product_id = max(product_sales, key=product_sales.get) if product_sales else None
    top_selling_product = "N/A"
    if top_product_id:
        product = next((p for p in products_data if p["id"] == top_product_id), None)
        if product:
            top_selling_product = product["name"]
    
    return KPIMetrics(
        total_revenue=total_revenue,
        total_sales=total_sales,
        total_products=total_products,
        average_order_value=average_order_value,
        top_selling_product=top_selling_product,
        revenue_growth=15.5  # Mock data
    )

# File Upload Routes
@app.post("/api/sales/upload")
async def upload_sales_data(
    file: UploadFile = File(...),
    current_user: dict = Depends(get_current_user)
):
    """Upload sales data from CSV/Excel file"""
    if not check_permission(current_user, action="create"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions"
        )
    
    if not file.filename.endswith(('.csv', '.xlsx')):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="File must be CSV or Excel format"
        )
    
    try:
        content = await file.read()
        
        if file.filename.endswith('.csv'):
            df = pd.read_csv(io.StringIO(content.decode('utf-8')))
        else:
            df = pd.read_excel(io.BytesIO(content))
        
        # Process uploaded data (simplified)
        uploaded_count = len(df)
        logger.info(f"Sales data uploaded by {current_user['email']}: {uploaded_count} records")
        
        return {
            "message": f"Successfully uploaded {uploaded_count} sales records",
            "records_processed": uploaded_count,
            "filename": file.filename
        }
        
    except Exception as e:
        logger.error(f"Error processing uploaded file: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Error processing file: {str(e)}"
        )

if __name__ == "__main__":
    uvicorn.run(
        "enhanced_api_server:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
