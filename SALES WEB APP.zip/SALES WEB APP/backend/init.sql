-- Create initial admin user
INSERT INTO users (email, hashed_password, full_name, role, is_active) VALUES
('admin@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/8KzKz2K', 'Admin User', 'admin', true),
('analyst@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/8KzKz2K', 'Analyst User', 'analyst', true),
('viewer@example.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/8KzKz2K', 'Viewer User', 'viewer', true);

-- Create sample products
INSERT INTO products (name, category, description, unit_price, cost_price) VALUES
('Laptop Pro 15"', 'Electronics', 'High-performance laptop for professionals', 1299.99, 800.00),
('Wireless Mouse', 'Electronics', 'Ergonomic wireless mouse with long battery life', 49.99, 25.00),
('Office Chair', 'Furniture', 'Comfortable ergonomic office chair', 299.99, 150.00),
('Standing Desk', 'Furniture', 'Adjustable height standing desk', 599.99, 300.00),
('Coffee Maker', 'Appliances', 'Programmable coffee maker with timer', 89.99, 45.00),
('Monitor 27"', 'Electronics', '4K Ultra HD monitor for professional use', 399.99, 200.00),
('Keyboard Mechanical', 'Electronics', 'RGB mechanical keyboard with blue switches', 129.99, 65.00),
('Desk Lamp', 'Furniture', 'LED desk lamp with adjustable brightness', 79.99, 35.00),
('Bluetooth Speaker', 'Electronics', 'Portable Bluetooth speaker with great sound', 99.99, 50.00),
('Notebook Set', 'Office Supplies', 'Premium notebook set with pen', 24.99, 12.00);

-- Create sample sales data for the last 6 months
INSERT INTO sales (product_id, quantity, unit_price, total_amount, sale_date, region, customer_name, sales_rep) VALUES
-- January 2024
(1, 2, 1299.99, 2599.98, '2024-01-15', 'North', 'John Smith', 'Alice Johnson'),
(2, 5, 49.99, 249.95, '2024-01-16', 'North', 'Jane Doe', 'Alice Johnson'),
(3, 1, 299.99, 299.99, '2024-01-17', 'South', 'Bob Wilson', 'Mike Brown'),
(4, 1, 599.99, 599.99, '2024-01-18', 'East', 'Sarah Davis', 'Lisa Green'),
(5, 3, 89.99, 269.97, '2024-01-19', 'West', 'Tom Anderson', 'David Lee'),

-- February 2024
(1, 1, 1299.99, 1299.99, '2024-02-10', 'North', 'Emily Chen', 'Alice Johnson'),
(6, 2, 399.99, 799.98, '2024-02-11', 'South', 'Mark Taylor', 'Mike Brown'),
(7, 4, 129.99, 519.96, '2024-02-12', 'East', 'Lisa Wang', 'Lisa Green'),
(8, 2, 79.99, 159.98, '2024-02-13', 'West', 'Chris Rodriguez', 'David Lee'),
(9, 1, 99.99, 99.99, '2024-02-14', 'North', 'Amy Johnson', 'Alice Johnson'),

-- March 2024
(2, 3, 49.99, 149.97, '2024-03-05', 'South', 'Kevin Park', 'Mike Brown'),
(3, 2, 299.99, 599.98, '2024-03-06', 'East', 'Rachel Kim', 'Lisa Green'),
(4, 1, 599.99, 599.99, '2024-03-07', 'West', 'Daniel Liu', 'David Lee'),
(5, 2, 89.99, 179.98, '2024-03-08', 'North', 'Michelle Garcia', 'Alice Johnson'),
(10, 10, 24.99, 249.90, '2024-03-09', 'South', 'Andrew White', 'Mike Brown'),

-- April 2024
(1, 3, 1299.99, 3899.97, '2024-04-12', 'East', 'Jennifer Martinez', 'Lisa Green'),
(6, 1, 399.99, 399.99, '2024-04-13', 'West', 'Robert Thompson', 'David Lee'),
(7, 2, 129.99, 259.98, '2024-04-14', 'North', 'Stephanie Clark', 'Alice Johnson'),
(8, 3, 79.99, 239.97, '2024-04-15', 'South', 'James Lewis', 'Mike Brown'),
(9, 2, 99.99, 199.98, '2024-04-16', 'East', 'Nicole Walker', 'Lisa Green'),

-- May 2024
(2, 4, 49.99, 199.96, '2024-05-08', 'West', 'Brandon Hall', 'David Lee'),
(3, 1, 299.99, 299.99, '2024-05-09', 'North', 'Samantha Young', 'Alice Johnson'),
(4, 2, 599.99, 1199.98, '2024-05-10', 'South', 'Tyler Allen', 'Mike Brown'),
(5, 1, 89.99, 89.99, '2024-05-11', 'East', 'Hannah King', 'Lisa Green'),
(10, 5, 24.99, 124.95, '2024-05-12', 'West', 'Zachary Wright', 'David Lee'),

-- June 2024
(1, 2, 1299.99, 2599.98, '2024-06-20', 'North', 'Olivia Scott', 'Alice Johnson'),
(6, 3, 399.99, 1199.97, '2024-06-21', 'South', 'Ethan Torres', 'Mike Brown'),
(7, 1, 129.99, 129.99, '2024-06-22', 'East', 'Grace Nguyen', 'Lisa Green'),
(8, 2, 79.99, 159.98, '2024-06-23', 'West', 'Caleb Hill', 'David Lee'),
(9, 3, 99.99, 299.97, '2024-06-24', 'North', 'Ava Flores', 'Alice Johnson');

-- Note: The password hash above is for 'admin123', 'analyst123', 'viewer123' respectively
-- In production, use proper password hashing
