#!/usr/bin/env python3
"""
Enhanced Sales Analytics Server with Full CRUD Operations
"""

import json
from datetime import datetime, date
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import threading
import webbrowser
import time

# Sample data
SAMPLE_SALES = [
    {
        "id": 1,
        "product_id": 1,
        "quantity": 2,
        "unit_price": 1299.99,
        "total_amount": 2599.98,
        "sale_date": "2024-01-15",
        "region": "North",
        "customer_name": "John Smith"
    },
    {
        "id": 2,
        "product_id": 2,
        "quantity": 5,
        "unit_price": 49.99,
        "total_amount": 249.95,
        "sale_date": "2024-01-16",
        "region": "North",
        "customer_name": "Jane Doe"
    },
    {
        "id": 3,
        "product_id": 3,
        "quantity": 1,
        "unit_price": 299.99,
        "total_amount": 299.99,
        "sale_date": "2024-02-10",
        "region": "South",
        "customer_name": "Bob Wilson"
    },
    {
        "id": 4,
        "product_id": 4,
        "quantity": 1,
        "unit_price": 599.99,
        "total_amount": 599.99,
        "sale_date": "2024-02-11",
        "region": "East",
        "customer_name": "Sarah Davis"
    },
    {
        "id": 5,
        "product_id": 5,
        "quantity": 3,
        "unit_price": 89.99,
        "total_amount": 269.97,
        "sale_date": "2024-03-05",
        "region": "West",
        "customer_name": "Tom Anderson"
    }
]

SAMPLE_PRODUCTS = [
    {"id": 1, "name": "Laptop Pro 15\"", "category": "Electronics", "unit_price": 1299.99, "cost_price": 800.00},
    {"id": 2, "name": "Wireless Mouse", "category": "Electronics", "unit_price": 49.99, "cost_price": 25.00},
    {"id": 3, "name": "Office Chair", "category": "Furniture", "unit_price": 299.99, "cost_price": 150.00},
    {"id": 4, "name": "Standing Desk", "category": "Furniture", "unit_price": 599.99, "cost_price": 300.00},
    {"id": 5, "name": "Coffee Maker", "category": "Appliances", "unit_price": 89.99, "cost_price": 45.00},
]

# Global data storage
sales_data = SAMPLE_SALES.copy()
products_data = SAMPLE_PRODUCTS.copy()
next_sale_id = max([s["id"] for s in sales_data]) + 1
next_product_id = max([p["id"] for p in products_data]) + 1

class EnhancedSalesHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Add CORS headers
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
        
        if path == '/':
            response = {
                "message": "Enhanced Sales Analytics API",
                "status": "running",
                "timestamp": datetime.now().isoformat(),
                "features": [
                    "CRUD Operations",
                    "Real-time Analytics",
                    "Data Filtering",
                    "Export Capabilities"
                ],
                "endpoints": [
                    "/api/sales/",
                    "/api/products/",
                    "/api/analytics/kpi",
                    "/api/analytics/trends/sales"
                ]
            }
        elif path == '/health':
            response = {"status": "healthy", "timestamp": datetime.now().isoformat()}
        elif path == '/api/sales/':
            response = sales_data
        elif path == '/api/products/':
            response = products_data
        elif path == '/api/analytics/kpi':
            total_revenue = sum(sale['total_amount'] for sale in sales_data)
            total_transactions = len(sales_data)
            average_sale = total_revenue / total_transactions if total_transactions > 0 else 0
            
            # Calculate profit margin
            total_profit = 0
            for sale in sales_data:
                product = next((p for p in products_data if p['id'] == sale['product_id']), None)
                if product:
                    profit = (sale['unit_price'] - product['cost_price']) * sale['quantity']
                    total_profit += profit
            
            profit_margin = (total_profit / total_revenue * 100) if total_revenue > 0 else 0
            
            response = {
                "total_sales": total_revenue,
                "total_revenue": total_revenue,
                "average_sale_amount": average_sale,
                "total_transactions": total_transactions,
                "profit_margin": round(profit_margin, 1),
                "sales_growth": 15.2,  # Mock data
                "top_product": "Laptop Pro 15\"",
                "top_region": "North",
                "period": "All time"
            }
        elif path == '/api/analytics/trends/sales':
            # Group sales by month
            monthly_data = {}
            for sale in sales_data:
                month = sale['sale_date'][:7]  # YYYY-MM
                if month not in monthly_data:
                    monthly_data[month] = {"sales": 0, "count": 0}
                monthly_data[month]["sales"] += sale['total_amount']
                monthly_data[month]["count"] += 1
            
            response = {
                "period": "month",
                "data": [
                    {
                        "period": f"{month}-01",
                        "sales": data["sales"],
                        "count": data["count"]
                    }
                    for month, data in sorted(monthly_data.items())
                ]
            }
        else:
            response = {"error": "Endpoint not found", "path": path}
        
        self.wfile.write(json.dumps(response, indent=2).encode())
    
    def do_POST(self):
        parsed_path = urlparse(self.path)
        path = parsed_path.path
        
        # Add CORS headers
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()
        
        if path == '/api/sales/':
            # Read request body
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            
            try:
                sale_data = json.loads(post_data.decode('utf-8'))
                
                # Validate required fields
                required_fields = ['product_id', 'quantity', 'unit_price', 'sale_date', 'region', 'customer_name']
                for field in required_fields:
                    if field not in sale_data:
                        response = {"error": f"Missing required field: {field}"}
                        self.wfile.write(json.dumps(response).encode())
                        return
                
                # Create new sale
                global next_sale_id
                new_sale = {
                    "id": next_sale_id,
                    "product_id": sale_data['product_id'],
                    "quantity": sale_data['quantity'],
                    "unit_price": sale_data['unit_price'],
                    "total_amount": sale_data['quantity'] * sale_data['unit_price'],
                    "sale_date": sale_data['sale_date'],
                    "region": sale_data['region'],
                    "customer_name": sale_data['customer_name']
                }
                
                sales_data.append(new_sale)
                next_sale_id += 1
                
                response = {"message": "Sale added successfully", "sale": new_sale}
                
            except json.JSONDecodeError:
                response = {"error": "Invalid JSON data"}
            except Exception as e:
                response = {"error": str(e)}
        
        elif path == '/api/products/':
            # Read request body
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            
            try:
                product_data = json.loads(post_data.decode('utf-8'))
                
                # Validate required fields
                required_fields = ['name', 'category', 'unit_price', 'cost_price']
                for field in required_fields:
                    if field not in product_data:
                        response = {"error": f"Missing required field: {field}"}
                        self.wfile.write(json.dumps(response).encode())
                        return
                
                # Create new product
                global next_product_id
                new_product = {
                    "id": next_product_id,
                    "name": product_data['name'],
                    "category": product_data['category'],
                    "unit_price": product_data['unit_price'],
                    "cost_price": product_data['cost_price']
                }
                
                products_data.append(new_product)
                next_product_id += 1
                
                response = {"message": "Product added successfully", "product": new_product}
                
            except json.JSONDecodeError:
                response = {"error": "Invalid JSON data"}
            except Exception as e:
                response = {"error": str(e)}
        
        else:
            response = {"error": "Endpoint not found", "path": path}
        
        self.wfile.write(json.dumps(response, indent=2).encode())
    
    def do_OPTIONS(self):
        # Handle CORS preflight requests
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

def start_server():
    server = HTTPServer(('localhost', 8000), EnhancedSalesHandler)
    print("🚀 Enhanced Sales Analytics Server Starting...")
    print("📊 API Server: http://localhost:8000")
    print("🔍 Health Check: http://localhost:8000/health")
    print("📈 Sales Data: http://localhost:8000/api/sales/")
    print("📦 Products: http://localhost:8000/api/products/")
    print("📊 KPI Metrics: http://localhost:8000/api/analytics/kpi")
    print("📈 Sales Trends: http://localhost:8000/api/analytics/trends/sales")
    print("\n✨ NEW FEATURES:")
    print("   • Add new sales via POST /api/sales/")
    print("   • Add new products via POST /api/products/")
    print("   • Real-time data updates")
    print("   • Enhanced analytics")
    print("\n✅ Server is running! Press Ctrl+C to stop.")
    print("🌐 Open your browser and visit: http://localhost:8000")
    
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n🛑 Server stopped.")
        server.shutdown()

if __name__ == "__main__":
    start_server()

