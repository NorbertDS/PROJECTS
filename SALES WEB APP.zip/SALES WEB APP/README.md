# Sales Analytics Web Application

A comprehensive sales analytics platform with AI-powered insights, interactive dashboards, and role-based authentication.

## Features

- **Authentication & Authorization**: Secure login with role-based access (Admin, Analyst, Viewer)
- **Data Management**: Upload CSV/Excel files and store in PostgreSQL database
- **Analytics Dashboard**: Interactive charts showing sales by day, week, month, year
- **AI Insights**: Machine learning forecasting, anomaly detection, and natural language queries
- **Reports**: Profit & Loss statements with filtering and downloadable PDF/Excel reports
- **Mobile Responsive**: Works seamlessly on desktop and mobile devices

## Tech Stack

- **Backend**: Python FastAPI with SQLAlchemy ORM
- **Frontend**: React.js with Tailwind CSS and Recharts
- **Database**: PostgreSQL
- **AI/ML**: Scikit-learn for forecasting and anomaly detection
- **Deployment**: Docker with docker-compose

## Quick Start

### Prerequisites

- Docker and Docker Compose
- Node.js 18+ (for local development)
- Python 3.9+ (for local development)

### Using Docker (Recommended)

1. Clone the repository:
```bash
git clone <repository-url>
cd sales-analytics-app
```

2. Start all services:
```bash
docker-compose up -d
```

3. Access the application:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000
- API Documentation: http://localhost:8000/docs

### Local Development

#### Backend Setup

1. Navigate to backend directory:
```bash
cd backend
```

2. Create virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Set environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

5. Run database migrations:
```bash
alembic upgrade head
```

6. Start the server:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

#### Frontend Setup

1. Navigate to frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

## Default Credentials

- **Admin**: admin@example.com / admin123
- **Analyst**: analyst@example.com / analyst123
- **Viewer**: viewer@example.com / viewer123

## API Documentation

Once the backend is running, visit http://localhost:8000/docs for interactive API documentation.

## Project Structure

```
sales-analytics-app/
├── backend/
│   ├── app/
│   │   ├── api/
│   │   ├── core/
│   │   ├── models/
│   │   ├── schemas/
│   │   ├── services/
│   │   └── utils/
│   ├── alembic/
│   ├── tests/
│   └── requirements.txt
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── services/
│   │   └── utils/
│   └── package.json
├── docker-compose.yml
└── README.md
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

MIT License
