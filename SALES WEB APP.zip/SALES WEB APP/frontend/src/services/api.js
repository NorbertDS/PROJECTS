import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle auth errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  setToken: (token) => {
    if (token) {
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    } else {
      delete api.defaults.headers.common['Authorization'];
    }
  },

  login: async (email, password) => {
    const formData = new FormData();
    formData.append('username', email);
    formData.append('password', password);
    
    const response = await api.post('/api/auth/login', formData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });
    return response.data;
  },

  getCurrentUser: async () => {
    const response = await api.get('/api/auth/me');
    return response.data;
  },

  register: async (userData) => {
    const response = await api.post('/api/auth/register', userData);
    return response.data;
  },
};

export const salesAPI = {
  getSales: async (params = {}) => {
    const response = await api.get('/api/sales/', { params });
    return response.data;
  },

  getSale: async (id) => {
    const response = await api.get(`/api/sales/${id}`);
    return response.data;
  },

  createSale: async (saleData) => {
    const response = await api.post('/api/sales/', saleData);
    return response.data;
  },

  updateSale: async (id, saleData) => {
    const response = await api.put(`/api/sales/${id}`, saleData);
    return response.data;
  },

  deleteSale: async (id) => {
    const response = await api.delete(`/api/sales/${id}`);
    return response.data;
  },

  uploadSalesData: async (file) => {
    const formData = new FormData();
    formData.append('file', file);
    
    const response = await api.post('/api/sales/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  },

  getSalesSummary: async (params = {}) => {
    const response = await api.get('/api/sales/analytics/summary', { params });
    return response.data;
  },
};

export const productsAPI = {
  getProducts: async (params = {}) => {
    const response = await api.get('/api/products/', { params });
    return response.data;
  },

  getProduct: async (id) => {
    const response = await api.get(`/api/products/${id}`);
    return response.data;
  },

  createProduct: async (productData) => {
    const response = await api.post('/api/products/', productData);
    return response.data;
  },

  updateProduct: async (id, productData) => {
    const response = await api.put(`/api/products/${id}`, productData);
    return response.data;
  },

  deleteProduct: async (id) => {
    const response = await api.delete(`/api/products/${id}`);
    return response.data;
  },

  getCategories: async () => {
    const response = await api.get('/api/products/categories/list');
    return response.data;
  },
};

export const analyticsAPI = {
  getKPIMetrics: async (params = {}) => {
    const response = await api.get('/api/analytics/kpi', { params });
    return response.data;
  },

  getSalesForecast: async (forecastData) => {
    const response = await api.post('/api/analytics/forecast', forecastData);
    return response.data;
  },

  detectAnomalies: async (params = {}) => {
    const response = await api.get('/api/analytics/anomalies', { params });
    return response.data;
  },

  processNaturalLanguageQuery: async (query) => {
    const response = await api.post('/api/analytics/nl-query', { query_text: query });
    return response.data;
  },

  getRecentInsights: async (limit = 10) => {
    const response = await api.get('/api/analytics/insights/recent', { params: { limit } });
    return response.data;
  },

  getSalesTrends: async (params = {}) => {
    const response = await api.get('/api/analytics/trends/sales', { params });
    return response.data;
  },

  getTopProducts: async (params = {}) => {
    const response = await api.get('/api/analytics/top-products', { params });
    return response.data;
  },
};

export const reportsAPI = {
  getProfitLossReport: async (params = {}) => {
    const response = await api.get('/api/reports/profit-loss', { params });
    return response.data;
  },

  getSalesSummaryReport: async (params = {}) => {
    const response = await api.get('/api/reports/sales-summary', { params });
    return response.data;
  },

  downloadPDFReport: async (reportType, params = {}) => {
    const response = await api.get('/api/reports/download/pdf', {
      params: { report_type: reportType, ...params },
      responseType: 'blob',
    });
    return response.data;
  },

  downloadExcelReport: async (reportType, params = {}) => {
    const response = await api.get('/api/reports/download/excel', {
      params: { report_type: reportType, ...params },
      responseType: 'blob',
    });
    return response.data;
  },
};

export const usersAPI = {
  getUsers: async (params = {}) => {
    const response = await api.get('/api/users/', { params });
    return response.data;
  },

  getUser: async (id) => {
    const response = await api.get(`/api/users/${id}`);
    return response.data;
  },

  updateUser: async (id, userData) => {
    const response = await api.put(`/api/users/${id}`, userData);
    return response.data;
  },

  deleteUser: async (id) => {
    const response = await api.delete(`/api/users/${id}`);
    return response.data;
  },
};

export default api;
