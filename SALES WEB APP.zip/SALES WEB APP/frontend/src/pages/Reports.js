import React, { useState, useEffect } from 'react';
import { reportsAPI } from '../services/api';
import { 
  Download, 
  FileText, 
  Calendar,
  MapPin,
  Package,
  Filter,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import toast from 'react-hot-toast';

function Reports() {
  const [filters, setFilters] = useState({
    start_date: '',
    end_date: '',
    region: '',
    product_id: ''
  });
  const [profitLossReport, setProfitLossReport] = useState(null);
  const [salesSummaryReport, setSalesSummaryReport] = useState(null);
  const [loading, setLoading] = useState(false);

  const generateProfitLossReport = async () => {
    try {
      setLoading(true);
      const params = {};
      if (filters.start_date) params.start_date = filters.start_date;
      if (filters.end_date) params.end_date = filters.end_date;
      if (filters.region) params.region = filters.region;
      if (filters.product_id) params.product_id = filters.product_id;
      
      const response = await reportsAPI.getProfitLossReport(params);
      setProfitLossReport(response);
    } catch (error) {
      console.error('Failed to generate profit loss report:', error);
      toast.error('Failed to generate profit loss report');
    } finally {
      setLoading(false);
    }
  };

  const generateSalesSummaryReport = async () => {
    try {
      setLoading(true);
      const params = {};
      if (filters.start_date) params.start_date = filters.start_date;
      if (filters.end_date) params.end_date = filters.end_date;
      if (filters.region) params.region = filters.region;
      if (filters.product_id) params.product_id = filters.product_id;
      
      const response = await reportsAPI.getSalesSummaryReport(params);
      setSalesSummaryReport(response);
    } catch (error) {
      console.error('Failed to generate sales summary report:', error);
      toast.error('Failed to generate sales summary report');
    } finally {
      setLoading(false);
    }
  };

  const downloadPDF = async (reportType) => {
    try {
      const params = {};
      if (filters.start_date) params.start_date = filters.start_date;
      if (filters.end_date) params.end_date = filters.end_date;
      if (filters.region) params.region = filters.region;
      if (filters.product_id) params.product_id = filters.product_id;
      
      const blob = await reportsAPI.downloadPDFReport(reportType, params);
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${reportType}_report.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success('PDF report downloaded successfully');
    } catch (error) {
      console.error('Failed to download PDF:', error);
      toast.error('Failed to download PDF report');
    }
  };

  const downloadExcel = async (reportType) => {
    try {
      const params = {};
      if (filters.start_date) params.start_date = filters.start_date;
      if (filters.end_date) params.end_date = filters.end_date;
      if (filters.region) params.region = filters.region;
      if (filters.product_id) params.product_id = filters.product_id;
      
      const blob = await reportsAPI.downloadExcelReport(reportType, params);
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${reportType}_report.xlsx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
      
      toast.success('Excel report downloaded successfully');
    } catch (error) {
      console.error('Failed to download Excel:', error);
      toast.error('Failed to download Excel report');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Reports</h1>
        <p className="text-gray-600">Generate and download comprehensive business reports</p>
      </div>

      {/* Filters */}
      <div className="card">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Report Filters</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Start Date
            </label>
            <input
              type="date"
              value={filters.start_date}
              onChange={(e) => setFilters({...filters, start_date: e.target.value})}
              className="input"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              End Date
            </label>
            <input
              type="date"
              value={filters.end_date}
              onChange={(e) => setFilters({...filters, end_date: e.target.value})}
              className="input"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Region
            </label>
            <select
              value={filters.region}
              onChange={(e) => setFilters({...filters, region: e.target.value})}
              className="input"
            >
              <option value="">All Regions</option>
              <option value="North">North</option>
              <option value="South">South</option>
              <option value="East">East</option>
              <option value="West">West</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Product ID
            </label>
            <input
              type="number"
              value={filters.product_id}
              onChange={(e) => setFilters({...filters, product_id: e.target.value})}
              className="input"
              placeholder="Leave empty for all products"
            />
          </div>
        </div>
      </div>

      {/* Report Types */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Profit & Loss Report */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <DollarSign className="h-6 w-6 text-green-600 mr-3" />
              <h3 className="text-lg font-semibold text-gray-900">Profit & Loss Report</h3>
            </div>
          </div>
          
          <p className="text-gray-600 mb-4">
            Comprehensive profit and loss analysis with product and region breakdowns.
          </p>
          
          <div className="space-y-3">
            <button
              onClick={generateProfitLossReport}
              disabled={loading}
              className="btn btn-primary w-full"
            >
              {loading ? 'Generating...' : 'Generate Report'}
            </button>
            
            <div className="flex space-x-2">
              <button
                onClick={() => downloadPDF('profit-loss')}
                className="btn btn-secondary flex-1 flex items-center justify-center"
              >
                <Download className="h-4 w-4 mr-2" />
                PDF
              </button>
              <button
                onClick={() => downloadExcel('profit-loss')}
                className="btn btn-secondary flex-1 flex items-center justify-center"
              >
                <Download className="h-4 w-4 mr-2" />
                Excel
              </button>
            </div>
          </div>
        </div>

        {/* Sales Summary Report */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <TrendingUp className="h-6 w-6 text-blue-600 mr-3" />
              <h3 className="text-lg font-semibold text-gray-900">Sales Summary Report</h3>
            </div>
          </div>
          
          <p className="text-gray-600 mb-4">
            Detailed sales analysis with trends, top products, and performance metrics.
          </p>
          
          <div className="space-y-3">
            <button
              onClick={generateSalesSummaryReport}
              disabled={loading}
              className="btn btn-primary w-full"
            >
              {loading ? 'Generating...' : 'Generate Report'}
            </button>
            
            <div className="flex space-x-2">
              <button
                onClick={() => downloadPDF('sales-summary')}
                className="btn btn-secondary flex-1 flex items-center justify-center"
              >
                <Download className="h-4 w-4 mr-2" />
                PDF
              </button>
              <button
                onClick={() => downloadExcel('sales-summary')}
                className="btn btn-secondary flex-1 flex items-center justify-center"
              >
                <Download className="h-4 w-4 mr-2" />
                Excel
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Profit & Loss Report Results */}
      {profitLossReport && (
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Profit & Loss Summary</h3>
          
          {/* Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                ${profitLossReport.summary.total_revenue.toLocaleString()}
              </div>
              <div className="text-sm text-blue-800">Total Revenue</div>
            </div>
            <div className="text-center p-4 bg-red-50 rounded-lg">
              <div className="text-2xl font-bold text-red-600">
                ${profitLossReport.summary.total_costs.toLocaleString()}
              </div>
              <div className="text-sm text-red-800">Total Costs</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                ${profitLossReport.summary.gross_profit.toLocaleString()}
              </div>
              <div className="text-sm text-green-800">Gross Profit</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                {profitLossReport.summary.profit_margin.toFixed(1)}%
              </div>
              <div className="text-sm text-purple-800">Profit Margin</div>
            </div>
          </div>

          {/* Product Breakdown */}
          <div className="mb-6">
            <h4 className="text-md font-semibold text-gray-900 mb-3">Product Breakdown</h4>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Product
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Revenue
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Costs
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Profit
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Margin
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {Object.entries(profitLossReport.product_breakdown).map(([product, data]) => (
                    <tr key={product}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        {product}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${data.revenue.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${data.costs.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ${data.profit.toLocaleString()}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {data.margin.toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Sales Summary Report Results */}
      {salesSummaryReport && (
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Sales Summary</h3>
          
          {/* Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">
                {salesSummaryReport.summary.total_sales}
              </div>
              <div className="text-sm text-blue-800">Total Sales</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                ${salesSummaryReport.summary.total_revenue.toLocaleString()}
              </div>
              <div className="text-sm text-green-800">Total Revenue</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">
                ${salesSummaryReport.summary.average_sale_amount.toLocaleString()}
              </div>
              <div className="text-sm text-purple-800">Average Sale</div>
            </div>
          </div>

          {/* Top Products */}
          <div className="mb-6">
            <h4 className="text-md font-semibold text-gray-900 mb-3">Top Products</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {salesSummaryReport.top_products.slice(0, 6).map((product, index) => (
                <div key={index} className="p-4 border border-gray-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium text-gray-900">{product.name}</h5>
                    <span className="text-sm text-gray-500">#{index + 1}</span>
                  </div>
                  <div className="text-sm text-gray-600">
                    <div>Revenue: ${product.revenue.toLocaleString()}</div>
                    <div>Quantity: {product.quantity}</div>
                    <div>Sales: {product.sales_count}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Reports;
