import React, { useState, useEffect } from 'react';
import { analyticsAPI } from '../services/api';
import { 
  TrendingUp, 
  AlertTriangle, 
  Brain, 
  MessageSquare,
  Calendar,
  MapPin,
  BarChart3,
  LineChart as LineChartIcon
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import toast from 'react-hot-toast';

function Analytics() {
  const [activeTab, setActiveTab] = useState('forecast');
  const [forecastData, setForecastData] = useState(null);
  const [anomalies, setAnomalies] = useState(null);
  const [nlQuery, setNlQuery] = useState('');
  const [nlResponse, setNlResponse] = useState(null);
  const [loading, setLoading] = useState(false);
  const [forecastParams, setForecastParams] = useState({
    product_id: '',
    region: '',
    forecast_periods: 12,
    confidence_level: 0.95
  });

  const handleForecast = async () => {
    try {
      setLoading(true);
      const params = {
        ...forecastParams,
        product_id: forecastParams.product_id || null,
        region: forecastParams.region || null
      };
      const response = await analyticsAPI.getSalesForecast(params);
      setForecastData(response);
    } catch (error) {
      console.error('Failed to generate forecast:', error);
      toast.error('Failed to generate sales forecast');
    } finally {
      setLoading(false);
    }
  };

  const handleAnomalyDetection = async () => {
    try {
      setLoading(true);
      const response = await analyticsAPI.detectAnomalies();
      setAnomalies(response);
    } catch (error) {
      console.error('Failed to detect anomalies:', error);
      toast.error('Failed to detect anomalies');
    } finally {
      setLoading(false);
    }
  };

  const handleNaturalLanguageQuery = async () => {
    if (!nlQuery.trim()) {
      toast.error('Please enter a question');
      return;
    }

    try {
      setLoading(true);
      const response = await analyticsAPI.processNaturalLanguageQuery(nlQuery);
      setNlResponse(response);
    } catch (error) {
      console.error('Failed to process query:', error);
      toast.error('Failed to process your question');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'forecast', name: 'Sales Forecast', icon: TrendingUp },
    { id: 'anomalies', name: 'Anomaly Detection', icon: AlertTriangle },
    { id: 'nl-query', name: 'AI Insights', icon: Brain }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Analytics & AI Insights</h1>
        <p className="text-gray-600">Advanced analytics powered by machine learning</p>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === tab.id
                  ? 'border-primary-500 text-primary-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <tab.icon className="h-4 w-4 mr-2" />
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      {/* Forecast Tab */}
      {activeTab === 'forecast' && (
        <div className="space-y-6">
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Sales Forecasting</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Product ID (Optional)
                </label>
                <input
                  type="number"
                  value={forecastParams.product_id}
                  onChange={(e) => setForecastParams({...forecastParams, product_id: e.target.value})}
                  className="input"
                  placeholder="Leave empty for all products"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Region (Optional)
                </label>
                <select
                  value={forecastParams.region}
                  onChange={(e) => setForecastParams({...forecastParams, region: e.target.value})}
                  className="input"
                >
                  <option value="">All Regions</option>
                  <option value="North">North</option>
                  <option value="South">South</option>
                  <option value="East">East</option>
                  <option value="West">West</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Forecast Periods
                </label>
                <input
                  type="number"
                  value={forecastParams.forecast_periods}
                  onChange={(e) => setForecastParams({...forecastParams, forecast_periods: parseInt(e.target.value)})}
                  className="input"
                  min="1"
                  max="24"
                />
              </div>
              <div className="flex items-end">
                <button
                  onClick={handleForecast}
                  disabled={loading}
                  className="btn btn-primary w-full"
                >
                  {loading ? 'Generating...' : 'Generate Forecast'}
                </button>
              </div>
            </div>
          </div>

          {forecastData && (
            <div className="space-y-6">
              {/* Model Accuracy */}
              <div className="card">
                <h4 className="text-md font-semibold text-gray-900 mb-2">Model Performance</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary-600">
                      {(forecastData.model_accuracy * 100).toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-600">Model Accuracy (R²)</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">
                      {forecastData.forecast_data.length}
                    </div>
                    <div className="text-sm text-gray-600">Forecast Periods</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {forecastParams.confidence_level * 100}%
                    </div>
                    <div className="text-sm text-gray-600">Confidence Level</div>
                  </div>
                </div>
              </div>

              {/* Forecast Chart */}
              <div className="card">
                <h4 className="text-md font-semibold text-gray-900 mb-4">Sales Forecast</h4>
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={forecastData.forecast_data}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tick={{ fontSize: 12 }}
                        tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short' })}
                      />
                      <YAxis tick={{ fontSize: 12 }} />
                      <Tooltip 
                        formatter={(value) => [`$${value.toLocaleString()}`, 'Forecast']}
                        labelFormatter={(value) => new Date(value).toLocaleDateString()}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="forecast" 
                        stroke="#3B82F6" 
                        strokeWidth={2}
                        dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Insights */}
              <div className="card">
                <h4 className="text-md font-semibold text-gray-900 mb-4">AI Insights</h4>
                <div className="space-y-2">
                  {forecastData.insights.map((insight, index) => (
                    <div key={index} className="flex items-start">
                      <div className="flex-shrink-0 w-2 h-2 bg-primary-600 rounded-full mt-2 mr-3"></div>
                      <p className="text-sm text-gray-700">{insight}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Anomaly Detection Tab */}
      {activeTab === 'anomalies' && (
        <div className="space-y-6">
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Anomaly Detection</h3>
            <p className="text-gray-600 mb-4">
              Detect unusual patterns in your sales data that may indicate data quality issues or significant business events.
            </p>
            <button
              onClick={handleAnomalyDetection}
              disabled={loading}
              className="btn btn-primary"
            >
              {loading ? 'Analyzing...' : 'Detect Anomalies'}
            </button>
          </div>

          {anomalies && (
            <div className="space-y-6">
              {/* Anomaly Summary */}
              <div className="card">
                <h4 className="text-md font-semibold text-gray-900 mb-4">Anomaly Summary</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">
                      {anomalies.total_anomalies}
                    </div>
                    <div className="text-sm text-gray-600">Total Anomalies</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">
                      {anomalies.anomaly_rate.toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-600">Anomaly Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-600">
                      {anomalies.anomalies.length > 0 ? 'High' : 'Low'}
                    </div>
                    <div className="text-sm text-gray-600">Risk Level</div>
                  </div>
                </div>
              </div>

              {/* Anomalies List */}
              {anomalies.anomalies.length > 0 && (
                <div className="card">
                  <h4 className="text-md font-semibold text-gray-900 mb-4">Detected Anomalies</h4>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Date
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Sales Amount
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Transaction Count
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Anomaly Score
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {anomalies.anomalies.map((anomaly, index) => (
                          <tr key={index} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {new Date(anomaly.date).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              ${anomaly.sales.toLocaleString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {anomaly.count}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {anomaly.anomaly_score.toFixed(3)}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Insights */}
              <div className="card">
                <h4 className="text-md font-semibold text-gray-900 mb-4">AI Insights</h4>
                <div className="space-y-2">
                  {anomalies.insights.map((insight, index) => (
                    <div key={index} className="flex items-start">
                      <div className="flex-shrink-0 w-2 h-2 bg-orange-600 rounded-full mt-2 mr-3"></div>
                      <p className="text-sm text-gray-700">{insight}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Natural Language Query Tab */}
      {activeTab === 'nl-query' && (
        <div className="space-y-6">
          <div className="card">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">AI-Powered Insights</h3>
            <p className="text-gray-600 mb-4">
              Ask questions about your sales data in natural language and get AI-generated insights.
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ask a question about your sales data
                </label>
                <div className="flex space-x-3">
                  <input
                    type="text"
                    value={nlQuery}
                    onChange={(e) => setNlQuery(e.target.value)}
                    placeholder="e.g., What were my top 5 products last quarter?"
                    className="input flex-1"
                  />
                  <button
                    onClick={handleNaturalLanguageQuery}
                    disabled={loading}
                    className="btn btn-primary"
                  >
                    {loading ? 'Processing...' : 'Ask AI'}
                  </button>
                </div>
              </div>

              {/* Example Questions */}
              <div>
                <p className="text-sm font-medium text-gray-700 mb-2">Example questions:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {[
                    "What were my top 5 products last quarter?",
                    "Which region had the highest sales?",
                    "What is my total sales revenue?",
                    "Show me sales trends by month"
                  ].map((question, index) => (
                    <button
                      key={index}
                      onClick={() => setNlQuery(question)}
                      className="text-left p-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded"
                    >
                      {question}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {nlResponse && (
            <div className="card">
              <h4 className="text-md font-semibold text-gray-900 mb-4">AI Response</h4>
              <div className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Question:</strong> {nlResponse.query_text}
                  </p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-sm text-green-800">
                    <strong>Answer:</strong> {nlResponse.response_data.answer}
                  </p>
                </div>
                
                {nlResponse.response_data.data && (
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <h5 className="text-sm font-medium text-gray-900 mb-2">Supporting Data:</h5>
                    <pre className="text-xs text-gray-700 overflow-x-auto">
                      {JSON.stringify(nlResponse.response_data.data, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default Analytics;
